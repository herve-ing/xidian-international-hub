export interface Supervisor {id:string;name:string;zh:string;title:string;school:string;schoolFr:string;field:string;research:string[];researchFr:string[];levels:string[];languages:string[];email:string;international:string;source:string;initials:string;color:string;note:string;schools?:string[];directorySource?:string;profileImages?:string[];facultySource?:string;}
export const supervisors:Supervisor[]=[
  {
    "id": "li-chenxi",
    "name": "Li Chenxi",
    "zh": "李晨曦",
    "title": "Associate professor",
    "school": "Communication Engineering",
    "schoolFr": "Ingénierie des télécommunications",
    "field": "Communications",
    "research": [
      "Satellite communications",
      "Secure networks",
      "Intelligent covert communications"
    ],
    "researchFr": [
      "Communications satellitaires",
      "Réseaux sécurisés",
      "Communications intelligentes"
    ],
    "levels": [
      "Master",
      "PhD"
    ],
    "languages": [
      "ZH"
    ],
    "email": "chenxili@xidian.edu.cn",
    "international": "confirm",
    "source": "https://faculty.xidian.edu.cn/LICHENXI/en/index.htm",
    "initials": "LC",
    "color": "#d9e5e1",
    "note": "Supervision language and international places must be confirmed directly."
  },
  {
    "id": "li-jun",
    "name": "Li Jun",
    "zh": "李军",
    "title": "Professor",
    "school": "Electronic Engineering",
    "schoolFr": "Ingénierie électronique",
    "field": "Signal processing",
    "research": [
      "Radar signal processing",
      "MIMO radar",
      "Quantum sensing"
    ],
    "researchFr": [
      "Traitement du signal radar",
      "Radar MIMO",
      "Détection quantique"
    ],
    "levels": [
      "PhD"
    ],
    "languages": [
      "ZH"
    ],
    "email": "junli01@mail.xidian.edu.cn",
    "international": "confirm",
    "source": "https://web.xidian.edu.cn/junli/",
    "initials": "LJ",
    "color": "#e8ded2",
    "note": "Doctoral supervision is listed on the official faculty page. Availability must be confirmed."
  },
  {
    "id": "sheng-kai",
    "name": "Sheng Kai",
    "zh": "盛凯",
    "title": "Professor",
    "school": "Interdisciplinary Research",
    "schoolFr": "Recherche interdisciplinaire",
    "field": "Artificial intelligence",
    "research": [
      "Autonomous driving",
      "Image processing",
      "Sensor fusion"
    ],
    "researchFr": [
      "Conduite autonome",
      "Traitement d’images",
      "Fusion de capteurs"
    ],
    "levels": [
      "Master",
      "PhD"
    ],
    "languages": [
      "ZH"
    ],
    "email": "kaisheng@xidian.edu.cn",
    "international": "historical",
    "source": "https://faculty.xidian.edu.cn/shengkai/zh_CN/zsxx/421782/content/2331.htm",
    "initials": "SK",
    "color": "#e5dfed",
    "note": "A 2025 official announcement invited international applicants. Current availability and teaching language remain unconfirmed."
  },
  {
    "id": "sie-1383-3079",
    "name": "Sun Yongjun",
    "zh": "",
    "title": "",
    "school": "School of Telecommunications Engineering",
    "schoolFr": "Télécommunications",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1383/3079.htm",
    "initials": "SY",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Telecommunications Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Telecommunications_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/B/93/2D/6F2F58B0D6F81C969F88F020915_D962BE5E_60645.jpg"
    ]
  },
  {
    "id": "sie-1383-3077",
    "name": "Anthony TRIOUX",
    "zh": "",
    "title": "",
    "school": "School of Telecommunications Engineering",
    "schoolFr": "Télécommunications",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1383/3077.htm",
    "initials": "AT",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Telecommunications Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Telecommunications_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/A/F0/5D/40E472FA9CBE430353859DDF3AB_C4EDD0F8_10845A.jpg"
    ]
  },
  {
    "id": "sie-1383-3075",
    "name": "Sun Jinhua",
    "zh": "",
    "title": "",
    "school": "School of Telecommunications Engineering",
    "schoolFr": "Télécommunications",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1383/3075.htm",
    "initials": "SJ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Telecommunications Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Telecommunications_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/F/61/2E/CBCCBCC47174B0B79A52AB45FA1_4F00455D_8BF52.jpg"
    ]
  },
  {
    "id": "sie-1383-3064",
    "name": "Wang Tao",
    "zh": "",
    "title": "",
    "school": "School of Telecommunications Engineering",
    "schoolFr": "Télécommunications",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1383/3064.htm",
    "initials": "WT",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Telecommunications Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Telecommunications_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/28/0F/2B107E21C0D8982E5CD4546E68E_32C01AD9_6ED49.jpg"
    ]
  },
  {
    "id": "sie-1383-2664",
    "name": "Gu Huaxi",
    "zh": "",
    "title": "",
    "school": "School of Telecommunications Engineering",
    "schoolFr": "Télécommunications",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1383/2664.htm",
    "initials": "GH",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Telecommunications Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Telecommunications_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/1/23/75/0286864CE7D5254B69171B564EA_65E258D7_150428.jpg"
    ]
  },
  {
    "id": "sie-1383-2663",
    "name": "Wen Aijun",
    "zh": "",
    "title": "",
    "school": "School of Telecommunications Engineering",
    "schoolFr": "Télécommunications",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1383/2663.htm",
    "initials": "WA",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Telecommunications Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Telecommunications_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/9D/32/77F5D3019F1F1DD10A6F2A642D4_88284F23_D0723.jpg"
    ]
  },
  {
    "id": "sie-1383-2662",
    "name": "Wu Wei",
    "zh": "",
    "title": "",
    "school": "School of Telecommunications Engineering",
    "schoolFr": "Télécommunications",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1383/2662.htm",
    "initials": "WW",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Telecommunications Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Telecommunications_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/8/D1/A1/93A5CBA3E8A2BCABC3DC32576DF_2BDF328C_793DC.jpg"
    ]
  },
  {
    "id": "sie-1383-2661",
    "name": "Xiang Zheng",
    "zh": "",
    "title": "",
    "school": "School of Telecommunications Engineering",
    "schoolFr": "Télécommunications",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1383/2661.htm",
    "initials": "XZ",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Telecommunications Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Telecommunications_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/ED/6D/DFF64E4C778888849CD2ED8B43A_7B52D3C0_8D8D5.jpg"
    ]
  },
  {
    "id": "sie-1383-2660",
    "name": "Zhang Yang",
    "zh": "",
    "title": "",
    "school": "School of Telecommunications Engineering",
    "schoolFr": "Télécommunications",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1383/2660.htm",
    "initials": "ZY",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Telecommunications Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Telecommunications_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/8/7E/F0/25383F172F5FF4405EF34383B46_1FDD67A4_D66B5.jpg"
    ]
  },
  {
    "id": "sie-1383-2659",
    "name": "Zhao Liqiang",
    "zh": "",
    "title": "",
    "school": "School of Telecommunications Engineering",
    "schoolFr": "Télécommunications",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1383/2659.htm",
    "initials": "ZL",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Telecommunications Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Telecommunications_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/07/22/AAE23EAB223CA19BD607CE4FDF2_E4A21D04_B3A5D.jpg"
    ]
  },
  {
    "id": "sie-1385-2720",
    "name": "Bao Liang",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2720.htm",
    "initials": "BL",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/50/24/159CB6C52474327A6B89F22DF25_16B724D8_D1667.jpg"
    ]
  },
  {
    "id": "sie-1385-2719",
    "name": "Dong Luobing",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2719.htm",
    "initials": "DL",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/08/C1/A5B6D72DFC48F0A5775D51013F1_D3985E40_DD5AC.jpg"
    ]
  },
  {
    "id": "sie-1385-2718",
    "name": "Dong Xuewen",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2718.htm",
    "initials": "DX",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/E/7E/AA/2EAD214D7878EA8B16096FA1C79_7E749D04_12B953.jpg"
    ]
  },
  {
    "id": "sie-1385-2717",
    "name": "Gao Haichang",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2717.htm",
    "initials": "GH",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/31/84/1AED52A9CB03CAC5E9978346F8A_670CFA9B_A660B.jpg"
    ]
  },
  {
    "id": "sie-1385-2716",
    "name": "Ji Jian",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2716.htm",
    "initials": "JJ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": []
  },
  {
    "id": "sie-1385-2715",
    "name": "Gu Guang",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2715.htm",
    "initials": "GG",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/1/73/EB/DA654A605C9CDBBAD0A59AB1CB2_C45BE5C5_A65A8.jpg"
    ]
  },
  {
    "id": "sie-1385-2714",
    "name": "Li He",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2714.htm",
    "initials": "LH",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": []
  },
  {
    "id": "sie-1385-2713",
    "name": "Lin Yishuai",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2713.htm",
    "initials": "LY",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/E4/7C/64808312A09F31EAC5B793197D5_382FD657_1B8022.jpg"
    ]
  },
  {
    "id": "sie-1385-2712",
    "name": "Liu Xiangzeng",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2712.htm",
    "initials": "LX",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/0E/86/F4E846F75C1032A824D1B5C773B_85C91F6C_AA86B.jpg"
    ]
  },
  {
    "id": "sie-1385-2711",
    "name": "Ma Xiaoke",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2711.htm",
    "initials": "MX",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/2/F9/FC/1586BF51002121B497F602B3DD0_4C79EB4C_75C7C.jpg"
    ]
  },
  {
    "id": "sie-1385-2710",
    "name": "Niu Zhenxing",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2710.htm",
    "initials": "NZ",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/F1/1A/006C860D4F79FBFE056ABEDD7E7_D69D9D50_8B511.jpg"
    ]
  },
  {
    "id": "sie-1385-2709",
    "name": "Shen Yulong",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2709.htm",
    "initials": "SY",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/8/DC/F6/FE41EFBFC55FD18D142D7B557D7_AED911D1_C753E.jpg"
    ]
  },
  {
    "id": "sie-1385-2708",
    "name": "Song Jianfeng",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2708.htm",
    "initials": "SJ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/65/70/4FE84B164D64B30D1A27CF72B7B_EDCEED77_9BD57.jpg"
    ]
  },
  {
    "id": "sie-1385-2707",
    "name": "Sun Penggang",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2707.htm",
    "initials": "SP",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/6E/37/11505FE5B550B84137145910C8E_FCD5D1F8_7BDD8.jpg"
    ]
  },
  {
    "id": "sie-1385-2706",
    "name": "Wan Bo",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2706.htm",
    "initials": "WB",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/7/00/ED/BDC0B0444CC09A803C5867634E1_6FF5FCBD_78C3F.jpg"
    ]
  },
  {
    "id": "sie-1385-2705",
    "name": "Wang Bingbo",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2705.htm",
    "initials": "WB",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/3/ED/76/855008B3D2157B79E942751F3E2_9768D5EA_8160D.jpg"
    ]
  },
  {
    "id": "sie-1385-2704",
    "name": "Wang Shuzhen",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2704.htm",
    "initials": "WS",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": []
  },
  {
    "id": "sie-1385-2703",
    "name": "Wang Xiaoli",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2703.htm",
    "initials": "WX",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/E/F0/77/B694D208316510BD20C02177D33_6CDAC39F_E5359.jpg"
    ]
  },
  {
    "id": "sie-1385-2702",
    "name": "Wu Yue",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2702.htm",
    "initials": "WY",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/7/BC/3C/61F60F57F144D793B9642CD4CD9_0DA9892E_1040B5.png"
    ]
  },
  {
    "id": "sie-1385-2701",
    "name": "Xie Fei",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2701.htm",
    "initials": "XF",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/7/86/1C/517B828240A2CE92E4130AD33F5_D78138AF_BA6AB.jpg"
    ]
  },
  {
    "id": "sie-1384-6725",
    "name": "Zhu Jiaqi",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/6725.htm",
    "initials": "ZJ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/F/B6/49/0AD3EB7E05BD7AC9294CE5CB1D6_B82E3668_7BE97B.jpg"
    ]
  },
  {
    "id": "sie-1384-3034",
    "name": "Xing Lining",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/3034.htm",
    "initials": "XL",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/C4/CE/60F41E1265FE77AD744494B0141_F3BFB7FC_33947.jpg"
    ]
  },
  {
    "id": "sie-1384-3032",
    "name": "Han Hong",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/3032.htm",
    "initials": "HH",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/64/79/8395F43F61BE33EFE6FD4BA60B8_DACFF432_43E5E.jpg"
    ]
  },
  {
    "id": "sie-1384-3030",
    "name": "Yuan Bing",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/3030.htm",
    "initials": "YB",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/8/E3/AC/7158E335A7A6AC0C75680A4FC3D_68B8A3D8_51A99.jpg"
    ]
  },
  {
    "id": "sie-1384-3028",
    "name": "Qin Guogong",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/3028.htm",
    "initials": "QG",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/39/5A/A03A260F2E48A53BE7DEE2DF73A_33E71E73_83B10.jpg"
    ]
  },
  {
    "id": "sie-1384-3026",
    "name": "Wang Qing",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/3026.htm",
    "initials": "WQ",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/F/9E/C2/3E780A0F1DACD47BF5AE7759E79_61B83BF6_65AFA.jpg"
    ]
  },
  {
    "id": "sie-1384-3024",
    "name": "Liu Nengwu",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/3024.htm",
    "initials": "LN",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/7/A0/35/AC9B7FB4C1BF63D45FB602BED9A_FD59E487_7CC73.jpg"
    ]
  },
  {
    "id": "sie-1384-3022",
    "name": "Zhu Cheng",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/3022.htm",
    "initials": "ZC",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/70/D1/7C0999A9FFFCE09CF58A11D2C15_3A2B7B4C_ACE5D.jpg"
    ]
  },
  {
    "id": "sie-1384-3019",
    "name": "Liu Gongxu",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/3019.htm",
    "initials": "LG",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/6/E9/F9/A5E0C671081A1D3F95CA4AA1D83_BDD4F165_6EE64.jpg"
    ]
  },
  {
    "id": "sie-1384-3017",
    "name": "Dong Ganggang",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/3017.htm",
    "initials": "DG",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/7/BC/5C/896B6B1FAD1255074929C5115EF_8D74748A_4054C.jpg"
    ]
  },
  {
    "id": "sie-1384-3015",
    "name": "Li Lin",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/3015.htm",
    "initials": "LL",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/07/B9/D1A0FCEF4BA3C1321858D0F93E6_F8BB1EA6_332D0.jpg"
    ]
  },
  {
    "id": "sie-1384-2694",
    "name": "Bao Min",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2694.htm",
    "initials": "BM",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": []
  },
  {
    "id": "sie-1384-2693",
    "name": "Chen Jianzhong",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2693.htm",
    "initials": "CJ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/4F/43/01D720BE9647C1D5C8EBEFC7C00_1C0CF5C5_D0301.png"
    ]
  },
  {
    "id": "sie-1384-2692",
    "name": "Chen Lei",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2692.htm",
    "initials": "CL",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/1/60/1A/FEC5E699117EF950FDAD91148F0_615A536F_E484D.png"
    ]
  },
  {
    "id": "sie-1384-2691",
    "name": "Chu Xiuqin",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2691.htm",
    "initials": "CX",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/E/9E/12/3F8EF2EAB254BFE82FEF8714055_FE357EE8_A35B3.png"
    ]
  },
  {
    "id": "sie-1384-2690",
    "name": "Gong Maoguo",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2690.htm",
    "initials": "GM",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/32/7A/8446D797FB2FAD3382C4F5B9537_6E40DEF6_111A63.png"
    ]
  },
  {
    "id": "sie-1384-2689",
    "name": "Jin Yan",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2689.htm",
    "initials": "JY",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/1A/32/7607D34332612073509C9317385_60DFDF8D_CC73A.png"
    ]
  },
  {
    "id": "sie-1384-2688",
    "name": "Lan Lan",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2688.htm",
    "initials": "LL",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/C5/1D/CCBFAAC46A57ED5DA20A949237E_DB7883A1_107347.png"
    ]
  },
  {
    "id": "sie-1384-2687",
    "name": "Li Long",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2687.htm",
    "initials": "LL",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/2/39/2C/19643F833C16D5BC8990A8E0ACD_1FE05F7A_9D689.png"
    ]
  },
  {
    "id": "sie-1384-2686",
    "name": "Liao Guisheng",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2686.htm",
    "initials": "LG",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/A/48/2A/26F815CA17B8C15540A3FF6C5D9_B2F1B58D_14DB05.png"
    ]
  },
  {
    "id": "sie-1386-3158",
    "name": "Liu Yongkui",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/3158.htm",
    "initials": "LY",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/6/79/47/78A2C192F7A97005312A9F1025A_96EFAC1D_98EF2.jpg"
    ]
  },
  {
    "id": "sie-1386-3005",
    "name": "Wang Weidong",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/3005.htm",
    "initials": "WW",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/3/7B/CF/21E92F9981963CF9F8A4409CB8D_D7701CDD_2C833.jpg"
    ]
  },
  {
    "id": "sie-1386-2737",
    "name": "Chen Yufeng",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/2737.htm",
    "initials": "CY",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/A/A1/FA/EE92D46DCCE3B7243896A4823E5_4AA3B0C7_B6EB3.png"
    ]
  },
  {
    "id": "sie-1386-2736",
    "name": "Dai Zhiyong",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/2736.htm",
    "initials": "DZ",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/F/CF/35/FD78746534DE83ADCB513CD8870_071244D6_78CDC.png"
    ]
  },
  {
    "id": "sie-1386-2735",
    "name": "Duan Qingjuan",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/2735.htm",
    "initials": "DQ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/A/5E/14/C2877F79C3D7E8319B3794EF1EA_A15B6740_AD136.png"
    ]
  },
  {
    "id": "sie-1386-2734",
    "name": "Hou Yifan",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/2734.htm",
    "initials": "HY",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/70/20/62E22B1CA63CFC31333FC50B337_1B34F21E_B7B3E.png"
    ]
  },
  {
    "id": "sie-1386-2732",
    "name": "Ji Jing",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/2732.htm",
    "initials": "JJ",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/6/E5/30/2A367DC5A8335B3D89309E5F926_1A13AF95_A1EA6.png"
    ]
  },
  {
    "id": "sie-1386-2731",
    "name": "Li Zhiwu",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/2731.htm",
    "initials": "LZ",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/8/00/96/49607E87258E9CF8DEFD52DB82A_50999E4B_97DB3.png"
    ]
  },
  {
    "id": "sie-1386-2730",
    "name": "Liu Ding",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/2730.htm",
    "initials": "LD",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/1/73/87/829463AEC1CA2F1CF37E1E4242F_72F39CD0_1144C1.png"
    ]
  },
  {
    "id": "sie-1386-2729",
    "name": "Liu Gaiyun",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/2729.htm",
    "initials": "LG",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/FB/A5/23C5588544CE8F27D91BC015833_1ACE00C8_C4907.png"
    ]
  },
  {
    "id": "sie-1386-2728",
    "name": "Ma Juan",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/2728.htm",
    "initials": "MJ",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/E8/F4/DD759A170710285CBC978347E0D_F8F65C33_F492C.png"
    ]
  },
  {
    "id": "sie-1386-2727",
    "name": "Ma Ziyue",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/2727.htm",
    "initials": "MZ",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/4/B9/FD/7BAFCDE46D69D4E585A30ED9615_42768F9E_BA45D.png"
    ]
  },
  {
    "id": "sie-1386-2726",
    "name": "Ping Xubin",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/2726.htm",
    "initials": "PX",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/6/A0/26/BAF99106C018A272256AAE2A8B7_78B97FAC_18DCF7.png"
    ]
  },
  {
    "id": "sie-1386-2725",
    "name": "Ren Huorong",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/2725.htm",
    "initials": "RH",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/3/75/30/48FA47AABB098EA3153D0C2F2FE_4498FD95_F6313.png"
    ]
  },
  {
    "id": "sie-1386-2724",
    "name": "Wang Xi",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/2724.htm",
    "initials": "WX",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/7/3D/A0/7BFB030E4B6D68549E8B7342B81_D8103095_B407F.png"
    ]
  },
  {
    "id": "sie-1386-2723",
    "name": "Zhang Jiafeng",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/2723.htm",
    "initials": "ZJ",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/7F/8B/13948E5C7896A4F8A27D22687F4_8EFB7CFE_1AAF93.png"
    ]
  },
  {
    "id": "sie-1386-2722",
    "name": "Zhou Jinzhu",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/2722.htm",
    "initials": "ZJ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/60/FE/F741EBEEF5311EA450D68E45FF0_3D5253D2_C2529.png"
    ]
  },
  {
    "id": "sie-1386-2721",
    "name": "Zhu Xiubin",
    "zh": "",
    "title": "",
    "school": "School of Mechano-electronic Engineering",
    "schoolFr": "Génie mécatronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1386/2721.htm",
    "initials": "ZX",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mechano-electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/4/CB/7C/89AC08ABEC713F387D3288E841E_06B55BDB_972F5.png"
    ]
  },
  {
    "id": "sie-1388-2778",
    "name": "Chen Xi",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2778.htm",
    "initials": "CX",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/B/33/35/529D9470790485042197C793472_FF5349BE_E8E74.png"
    ]
  },
  {
    "id": "sie-1388-2777",
    "name": "Dong Ming",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2777.htm",
    "initials": "DM",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/BB/4D/B6347477F2600F625950B3372AF_63613AED_CBD16.png"
    ]
  },
  {
    "id": "sie-1388-2776",
    "name": "Du Rong",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2776.htm",
    "initials": "DR",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/2/35/5B/3AC8367C8460EF973177AE5270C_036195C3_68D6B6.png"
    ]
  },
  {
    "id": "sie-1388-2775",
    "name": "Feng Pingping",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2775.htm",
    "initials": "FP",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": []
  },
  {
    "id": "sie-1388-2774",
    "name": "Geng Ruibin",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2774.htm",
    "initials": "GR",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/8/90/42/A46C46601C61CB3E49791CC53FA_1B3BCE26_E3C6A.png"
    ]
  },
  {
    "id": "sie-1388-2773",
    "name": "Hui Tiaoyan",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2773.htm",
    "initials": "HT",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/8/3B/BF/4A42EBF1E929AEB28A27CE519F3_71091852_10E3AC.png"
    ]
  },
  {
    "id": "sie-1388-2772",
    "name": "Jiang Xiaobing",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2772.htm",
    "initials": "JX",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/3/EC/85/61DA6111B890F4385DEE325CD94_1608A2E9_B41DD.png"
    ]
  },
  {
    "id": "sie-1388-2771",
    "name": "Lang Chungang",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2771.htm",
    "initials": "LC",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/D4/EC/DD160573CF55A7242D951389E7E_799400DF_A4843.png"
    ]
  },
  {
    "id": "sie-1388-2770",
    "name": "Liu Aijun",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2770.htm",
    "initials": "LA",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/EF/63/8809FCC2713340589B2F5A9C0EC_28FD1727_F57A3.png"
    ]
  },
  {
    "id": "sie-1388-2769",
    "name": "Shang Juan",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2769.htm",
    "initials": "SJ",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/38/99/E0CAAFF4F0959093C3EC41F8BAB_567B6DFA_10F82A.png"
    ]
  },
  {
    "id": "sie-1388-2768",
    "name": "Shen Zunhuan",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2768.htm",
    "initials": "SZ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/1/8A/B4/DD1F762382C46A62ED4B86F1E6B_F01609A2_9AF5B.png"
    ]
  },
  {
    "id": "sie-1388-2767",
    "name": "Shi Hongwei",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2767.htm",
    "initials": "SH",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/A/15/15/B26578E2ADECE645DF9A7FDE7C5_EFF8D16C_BC4BE.png"
    ]
  },
  {
    "id": "sie-1388-2766",
    "name": "Wang Tao",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2766.htm",
    "initials": "WT",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/A/E9/9F/9CE293294D5EEFA1B9A514D5DB2_54701C51_85E03.png"
    ]
  },
  {
    "id": "sie-1388-2765",
    "name": "Xie Yongping",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2765.htm",
    "initials": "XY",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/F/2E/2C/FC839F007BC5BF72C0AFB43C9D1_1D52304E_141334.png"
    ]
  },
  {
    "id": "sie-1388-2764",
    "name": "Xu Yaqing",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2764.htm",
    "initials": "XY",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/2/D8/77/3EA8B6C1D701C54D3F36A43AB59_B27A327E_7BDFC.png"
    ]
  },
  {
    "id": "sie-1388-2763",
    "name": "Zhang Jianjun",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2763.htm",
    "initials": "ZJ",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/85/17/930D5FE62E1A8F7D4556713BF7E_8D04E257_BA83C.png"
    ]
  },
  {
    "id": "sie-1388-2762",
    "name": "Zhang Xiong",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2762.htm",
    "initials": "ZX",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/E/4A/0D/84CAABA9F4369F4C5873637A1EC_C15A4F95_99878.png"
    ]
  },
  {
    "id": "sie-1388-2761",
    "name": "Zhang Zongming",
    "zh": "",
    "title": "",
    "school": "School of Economics and Management",
    "schoolFr": "Mathématiques et statistiques",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1388/2761.htm",
    "initials": "ZZ",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Economics and Management"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/B/62/6B/6EF7C2E0305C0F00715CAD77B2C_E19F3FD4_C7F06.png"
    ]
  },
  {
    "id": "sie-1387-3050",
    "name": "Cheng Mingjian",
    "zh": "",
    "title": "",
    "school": "School of Physics",
    "schoolFr": "Économie et gestion",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1387/3050.htm",
    "initials": "CM",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Physics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Physics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/A/A7/D6/63B70AF6CEB2E985915468E847A_A3B7B82E_55A10.jpg"
    ]
  },
  {
    "id": "sie-1387-2749",
    "name": "Gao Peng",
    "zh": "",
    "title": "",
    "school": "School of Physics",
    "schoolFr": "Économie et gestion",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1387/2749.htm",
    "initials": "GP",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Physics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Physics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/6/29/03/5B51CDA39973BCD8A7D56CE7601_46B6678D_73604.png"
    ]
  },
  {
    "id": "sie-1387-2748",
    "name": "Gong Shuhong",
    "zh": "",
    "title": "",
    "school": "School of Physics",
    "schoolFr": "Économie et gestion",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1387/2748.htm",
    "initials": "GS",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Physics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Physics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/9B/5C/83C9E3246E435CA9BD391749D4B_75401A6A_BD278.png"
    ]
  },
  {
    "id": "sie-1387-2747",
    "name": "Guo Lixin",
    "zh": "",
    "title": "",
    "school": "School of Physics",
    "schoolFr": "Économie et gestion",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1387/2747.htm",
    "initials": "GL",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Physics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Physics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/6/D7/48/49B139722B15CFA91B31B326749_997B7315_145A1C.png"
    ]
  },
  {
    "id": "sie-1387-2746",
    "name": "Han Yiping",
    "zh": "",
    "title": "",
    "school": "School of Physics",
    "schoolFr": "Économie et gestion",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1387/2746.htm",
    "initials": "HY",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Physics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Physics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/E/EB/2F/6046E15F6BA4CAB45D2BF17F8CB_47105892_9A7A9.png"
    ]
  },
  {
    "id": "sie-1387-2745",
    "name": "Li Haiying",
    "zh": "",
    "title": "",
    "school": "School of Physics",
    "schoolFr": "Économie et gestion",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1387/2745.htm",
    "initials": "LH",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Physics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Physics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/2/8B/F3/166151C676DAA415A512AB103F9_4A052058_969B4.png"
    ]
  },
  {
    "id": "sie-1387-2744",
    "name": "Li Tanping",
    "zh": "",
    "title": "",
    "school": "School of Physics",
    "schoolFr": "Économie et gestion",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1387/2744.htm",
    "initials": "LT",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Physics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Physics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/6/B3/43/F6483672673EBC5158A1A9B1223_255ED14B_67844.png"
    ]
  },
  {
    "id": "sie-1387-2743",
    "name": "Lin Ke",
    "zh": "",
    "title": "",
    "school": "School of Physics",
    "schoolFr": "Économie et gestion",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1387/2743.htm",
    "initials": "LK",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Physics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Physics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/2/C9/D2/10A9D5C8243EC34AD904833BA47_313874F9_BD6A4.png"
    ]
  },
  {
    "id": "sie-1387-2742",
    "name": "Wang Jiajie",
    "zh": "",
    "title": "",
    "school": "School of Physics",
    "schoolFr": "Économie et gestion",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1387/2742.htm",
    "initials": "WJ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Physics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Physics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/B/88/8D/3A8F3975F0B1CB5CDCA81B29F75_1F72988F_CFF56.png"
    ]
  },
  {
    "id": "sie-1387-2741",
    "name": "Wang Bingjian",
    "zh": "",
    "title": "",
    "school": "School of Physics",
    "schoolFr": "Économie et gestion",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1387/2741.htm",
    "initials": "WB",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Physics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Physics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/3/3C/AC/FD86802E33C3DF4A4ABECA56729_C0D1FD59_7CAB6.png"
    ]
  },
  {
    "id": "sie-1387-2740",
    "name": "Wang Junli",
    "zh": "",
    "title": "",
    "school": "School of Physics",
    "schoolFr": "Économie et gestion",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1387/2740.htm",
    "initials": "WJ",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Physics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Physics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/48/32/C8821A1935A4F9F4E1F5DDBA02E_7C063A22_C4E1D.png"
    ]
  },
  {
    "id": "sie-1387-2739",
    "name": "Wei Bing",
    "zh": "",
    "title": "",
    "school": "School of Physics",
    "schoolFr": "Économie et gestion",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1387/2739.htm",
    "initials": "WB",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Physics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Physics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/6/C1/14/DD2E48AFA55897D4958B410C5B6_650D1CA3_C2A25.png"
    ]
  },
  {
    "id": "sie-1387-2738",
    "name": "Zhou Huixin",
    "zh": "",
    "title": "",
    "school": "School of Physics",
    "schoolFr": "Économie et gestion",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1387/2738.htm",
    "initials": "ZH",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Physics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Physics.htm",
    "profileImages": []
  },
  {
    "id": "sie-1389-6825",
    "name": "Zhang Xin",
    "zh": "",
    "title": "",
    "school": "School of Mathematics and Statistics",
    "schoolFr": "Optoélectronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1389/6825.htm",
    "initials": "ZX",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mathematics and Statistics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mathematics_and_Statistics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/A/8A/23/0A29A015B9AD62C85EC25CEFA70_26A0A6E5_615B7F.jpg"
    ]
  },
  {
    "id": "sie-1389-2784",
    "name": "Bao Lijun",
    "zh": "",
    "title": "",
    "school": "School of Mathematics and Statistics",
    "schoolFr": "Optoélectronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1389/2784.htm",
    "initials": "BL",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mathematics and Statistics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mathematics_and_Statistics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/B/1A/84/21976586E95FB6E397A181640D3_0A633F88_B41BF.png"
    ]
  },
  {
    "id": "sie-1389-2783",
    "name": "Gao Weifeng",
    "zh": "",
    "title": "",
    "school": "School of Mathematics and Statistics",
    "schoolFr": "Optoélectronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1389/2783.htm",
    "initials": "GW",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mathematics and Statistics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mathematics_and_Statistics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/B/30/74/17C32D8CE2BDF31469804E3480D_7217A4CA_A8F1F.png"
    ]
  },
  {
    "id": "sie-1389-2782",
    "name": "Li Wei",
    "zh": "",
    "title": "",
    "school": "School of Mathematics and Statistics",
    "schoolFr": "Optoélectronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1389/2782.htm",
    "initials": "LW",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mathematics and Statistics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mathematics_and_Statistics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/EB/E6/F2E232DC1FB36807311B3B93109_B43B5724_BCE0E.png"
    ]
  },
  {
    "id": "sie-1389-2781",
    "name": "Wu Shiliang",
    "zh": "",
    "title": "",
    "school": "School of Mathematics and Statistics",
    "schoolFr": "Optoélectronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1389/2781.htm",
    "initials": "WS",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mathematics and Statistics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mathematics_and_Statistics.htm",
    "profileImages": []
  },
  {
    "id": "sie-1389-2780",
    "name": "Zhang Leyou",
    "zh": "",
    "title": "",
    "school": "School of Mathematics and Statistics",
    "schoolFr": "Optoélectronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1389/2780.htm",
    "initials": "ZL",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mathematics and Statistics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mathematics_and_Statistics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/8/93/FC/07F3ECE7FBE82AB30316FAEC365_6C0E86D5_7FFB7.png"
    ]
  },
  {
    "id": "sie-1389-2779",
    "name": "Zhu Qiang",
    "zh": "",
    "title": "",
    "school": "School of Mathematics and Statistics",
    "schoolFr": "Optoélectronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1389/2779.htm",
    "initials": "ZQ",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Mathematics and Statistics"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mathematics_and_Statistics.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/8/E5/06/AA2392A0C26795F381A53F80296_86C664C3_781EB.png"
    ]
  },
  {
    "id": "sie-1484-2760",
    "name": "Cao Changqing",
    "zh": "",
    "title": "",
    "school": "School of Optoelectronic Engineering",
    "schoolFr": "Physique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1484/2760.htm",
    "initials": "CC",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Optoelectronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Optoelectronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/2/B7/66/84C4A5A7E6FC082C5E87F2417F1_3B7D6E8D_7992F.png"
    ]
  },
  {
    "id": "sie-1484-2759",
    "name": "Liu Fei",
    "zh": "",
    "title": "",
    "school": "School of Optoelectronic Engineering",
    "schoolFr": "Physique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1484/2759.htm",
    "initials": "LF",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Optoelectronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Optoelectronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/B/03/24/B3F0AD6B1E7F17C0DB75B232F39_127A0199_AB278.png"
    ]
  },
  {
    "id": "sie-1484-2758",
    "name": "Liu Lixin",
    "zh": "",
    "title": "",
    "school": "School of Optoelectronic Engineering",
    "schoolFr": "Physique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1484/2758.htm",
    "initials": "LL",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Optoelectronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Optoelectronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/E/1D/8F/99ED4988DCC55DADB2551F0DACF_859E9C6B_9B05C.png"
    ]
  },
  {
    "id": "sie-1484-2757",
    "name": "Liu Lixian",
    "zh": "",
    "title": "",
    "school": "School of Optoelectronic Engineering",
    "schoolFr": "Physique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1484/2757.htm",
    "initials": "LL",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Optoelectronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Optoelectronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/8/49/28/FE44C224743B623FF6B9564B21A_1E2DC664_88ADC.png"
    ]
  },
  {
    "id": "sie-1484-2756",
    "name": "Qin Hanlin",
    "zh": "",
    "title": "",
    "school": "School of Optoelectronic Engineering",
    "schoolFr": "Physique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1484/2756.htm",
    "initials": "QH",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Optoelectronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Optoelectronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/E/78/5F/B0CA0699A1A0489D94C113A6A9A_706D39F1_DC08F.png"
    ]
  },
  {
    "id": "sie-1484-2755",
    "name": "Shao Xiaopeng",
    "zh": "",
    "title": "",
    "school": "School of Optoelectronic Engineering",
    "schoolFr": "Physique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1484/2755.htm",
    "initials": "SX",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Optoelectronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Optoelectronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/4/74/B7/6C464B9854CB03192512D99CD37_8A5B183B_E49DF.png"
    ]
  },
  {
    "id": "sie-1484-2754",
    "name": "Wang Lin",
    "zh": "",
    "title": "",
    "school": "School of Optoelectronic Engineering",
    "schoolFr": "Physique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1484/2754.htm",
    "initials": "WL",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Optoelectronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Optoelectronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/18/7C/E10FA3017657CD14C7E8E8D5F2B_8F10DC66_B2B81.png"
    ]
  },
  {
    "id": "sie-1484-2753",
    "name": "Wang Xiaorui",
    "zh": "",
    "title": "",
    "school": "School of Optoelectronic Engineering",
    "schoolFr": "Physique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1484/2753.htm",
    "initials": "WX",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Optoelectronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Optoelectronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/EB/A5/C707F3891791EC8BBF5C4D8EA13_03941F3A_9C675.png"
    ]
  },
  {
    "id": "sie-1484-2752",
    "name": "Yin Xukun",
    "zh": "",
    "title": "",
    "school": "School of Optoelectronic Engineering",
    "schoolFr": "Physique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1484/2752.htm",
    "initials": "YX",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Optoelectronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Optoelectronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/B9/15/88203BEA7E3FC88E5C582AE7EE1_AB491CF6_933F7.png"
    ]
  },
  {
    "id": "sie-1484-2751",
    "name": "Zhang Dacheng",
    "zh": "",
    "title": "",
    "school": "School of Optoelectronic Engineering",
    "schoolFr": "Physique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1484/2751.htm",
    "initials": "ZD",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Optoelectronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Optoelectronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/A4/C2/01F699E9B70D65FAE17B40D4C50_33EC1F1E_A3CCF.png"
    ]
  },
  {
    "id": "sie-1484-2750",
    "name": "Zhu Jiangfeng",
    "zh": "",
    "title": "",
    "school": "School of Optoelectronic Engineering",
    "schoolFr": "Physique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1484/2750.htm",
    "initials": "ZJ",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Optoelectronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Optoelectronic_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/3/85/0B/A364102F953A1A1D630A8BA5A49_25A6F722_99443.png"
    ]
  },
  {
    "id": "sie-1390-6795",
    "name": "Xiang Shuchen",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/6795.htm",
    "initials": "XS",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/3/FC/9E/D6C435F205FFFAD8C634F9393EA_11A8C87A_AA4FE3.jpg"
    ]
  },
  {
    "id": "sie-1390-6785",
    "name": "Sun Wen",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/6785.htm",
    "initials": "SW",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/4/23/5B/676FEDEDC0B30A6014D8507CE76_6F1C2CB6_51E05F.jpg"
    ]
  },
  {
    "id": "sie-1390-6775",
    "name": "Shi Weijun",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/6775.htm",
    "initials": "SW",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/16/53/1AA20B43C3349E9B9A8306011D5_6FDF0001_4B62F2.jpg"
    ]
  },
  {
    "id": "sie-1390-6765",
    "name": "Lv Shuang",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/6765.htm",
    "initials": "LS",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/86/5B/AFC9AF5FC435C482E9AED3227D6_41C1CC0E_407024.jpg"
    ]
  },
  {
    "id": "sie-1390-6755",
    "name": "Jacob Bender",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/6755.htm",
    "initials": "JB",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/8/B8/3A/FD1D3DF758C05E512CA36E2A5F0_732520DB_683F4F.jpg"
    ]
  },
  {
    "id": "sie-1390-2799",
    "name": "Chen Zhiwei",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/2799.htm",
    "initials": "CZ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/B7/A9/F4929A166E4363B18BBAB7BD100_4856FF59_81E7E.jpg"
    ]
  },
  {
    "id": "sie-1390-2797",
    "name": "Dong Yongqiang",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/2797.htm",
    "initials": "DY",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/7/75/68/EFB64F95D29CCD13DE6931312D3_DC3221FE_DB099.jpg"
    ]
  },
  {
    "id": "sie-1390-2796",
    "name": "Ma Delin",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/2796.htm",
    "initials": "MD",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/B6/C1/AC31BBD7DB2D02CED16DE1F231B_1059B47A_84039.jpg"
    ]
  },
  {
    "id": "sie-1390-2795",
    "name": "Ma Xiaohu",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/2795.htm",
    "initials": "MX",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/B/36/A4/F92A1A28229CCAE515872FF2F7B_719443BF_92ABF.jpg"
    ]
  },
  {
    "id": "sie-1390-2794",
    "name": "Pan Mingjuan",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/2794.htm",
    "initials": "PM",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/A/2C/B7/947677C30C1FFF142783DAA36FA_C7D7B10F_A3D0D.jpg"
    ]
  },
  {
    "id": "sie-1390-2793",
    "name": "Shi Shaobo",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/2793.htm",
    "initials": "SS",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/4/B7/BF/10E1481AD8FD2A1872FC6CB4854_37657260_7FE4A.png"
    ]
  },
  {
    "id": "sie-1390-2792",
    "name": "Su Li",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/2792.htm",
    "initials": "SL",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/CF/C7/1A169352802B046212CB0DDD4A2_176F310B_894B4.jpg"
    ]
  },
  {
    "id": "sie-1390-2791",
    "name": "Su Xiaobing",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/2791.htm",
    "initials": "SX",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/EB/73/2FB18AB8569F71AE426C96005B2_ED0EB479_CE9C2.jpg"
    ]
  },
  {
    "id": "sie-1390-2790",
    "name": "Wang Chenguang",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/2790.htm",
    "initials": "WC",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/7/0D/49/D300A8585F6688C41456B0D57E5_E8B8803D_BE455.jpg"
    ]
  },
  {
    "id": "sie-1390-2789",
    "name": "Wang Shi",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/2789.htm",
    "initials": "WS",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/1E/94/0DB266242FCB384106924C7EC75_1ECD8B85_87474.jpg"
    ]
  },
  {
    "id": "sie-1390-2788",
    "name": "Xu Yongqiang",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/2788.htm",
    "initials": "XY",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/A2/4A/D5F11DFB07A5AE6F06FC9032E65_4545AA26_77C0D.jpg"
    ]
  },
  {
    "id": "sie-1390-2787",
    "name": "Zhang Simin",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/2787.htm",
    "initials": "ZS",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/3D/20/AD3C3451A6AE86A2C096E3EDA0B_D01B0C1D_81B53.jpg"
    ]
  },
  {
    "id": "sie-1390-2786",
    "name": "Zhang Wanqiang",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/2786.htm",
    "initials": "ZW",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/E/BB/6F/D04EEA405B2D0D75A871FD7E3FA_474EF0A4_65E22.jpg"
    ]
  },
  {
    "id": "sie-1390-2785",
    "name": "Zhu Jianing",
    "zh": "",
    "title": "",
    "school": "School of Humanities and Arts",
    "schoolFr": "Sciences humaines et arts",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1390/2785.htm",
    "initials": "ZJ",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Humanities and Arts"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/C1/5F/916B10C598AA9DBCB0CDB023B97_186B28BA_B1DB0.jpg"
    ]
  },
  {
    "id": "sie-1391-2803",
    "name": "Chen Zhengfeng",
    "zh": "",
    "title": "",
    "school": "School of Foreign Languages",
    "schoolFr": "Langues étrangères",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1391/2803.htm",
    "initials": "CZ",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Foreign Languages"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Foreign_Languages.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/CB/3F/8DA8AFF19139D3562E9F8B312DC_EE6753AD_C41CD.png"
    ]
  },
  {
    "id": "sie-1391-2802",
    "name": "Li Shuqing",
    "zh": "",
    "title": "",
    "school": "School of Foreign Languages",
    "schoolFr": "Langues étrangères",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1391/2802.htm",
    "initials": "LS",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Foreign Languages"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Foreign_Languages.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/F/72/6B/08E1C58FAEE3138FE3216F6341D_691B6ED8_B8A8B.png"
    ]
  },
  {
    "id": "sie-1391-2801",
    "name": "Liu Jianshu",
    "zh": "",
    "title": "",
    "school": "School of Foreign Languages",
    "schoolFr": "Langues étrangères",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1391/2801.htm",
    "initials": "LJ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Foreign Languages"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Foreign_Languages.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/F/2B/87/A7D756A93E7F66EC9F52BBC481C_CE0E4296_51AFC.png"
    ]
  },
  {
    "id": "sie-1391-2800",
    "name": "Zhou Zhenglv",
    "zh": "",
    "title": "",
    "school": "School of Foreign Languages",
    "schoolFr": "Langues étrangères",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1391/2800.htm",
    "initials": "ZZ",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Foreign Languages"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Foreign_Languages.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/7/72/58/09DABC3F529BA777D7FCD5B0D40_B1D5CF5B_99070.png"
    ]
  },
  {
    "id": "sie-1393-6815",
    "name": "Liu Jixin",
    "zh": "",
    "title": "",
    "school": "School of Life Science and Technology",
    "schoolFr": "Cybersécurité",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1393/6815.htm",
    "initials": "LJ",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Life Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Life_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/F/51/B5/5062A23474D10EB50B9F652FD21_420DBAD6_4E8075.jpg"
    ]
  },
  {
    "id": "sie-1393-6805",
    "name": "Cao Zhicheng",
    "zh": "",
    "title": "",
    "school": "School of Life Science and Technology",
    "schoolFr": "Cybersécurité",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1393/6805.htm",
    "initials": "CZ",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Life Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Life_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/2B/9D/DFC8DFF6C4BFF0F9AC846584582_94CF1CEF_532114.jpg"
    ]
  },
  {
    "id": "sie-1393-3008",
    "name": "Zhao Heng",
    "zh": "",
    "title": "",
    "school": "School of Life Science and Technology",
    "schoolFr": "Cybersécurité",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1393/3008.htm",
    "initials": "ZH",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Life Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Life_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/F/8D/95/BD1D16806515D6D3D73276C355A_87A66AED_383F5.jpg"
    ]
  },
  {
    "id": "sie-1393-2828",
    "name": "Cao Xu",
    "zh": "",
    "title": "",
    "school": "School of Life Science and Technology",
    "schoolFr": "Cybersécurité",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1393/2828.htm",
    "initials": "CX",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Life Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Life_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/6C/F9/7D4A121684A77D217072C4F8EE9_9CFB9BF5_D0442.png"
    ]
  },
  {
    "id": "sie-1393-2827",
    "name": "Chen Xueli",
    "zh": "",
    "title": "",
    "school": "School of Life Science and Technology",
    "schoolFr": "Cybersécurité",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1393/2827.htm",
    "initials": "CX",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Life Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Life_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/6/C0/1D/E830CD66AD4F94D0AB4E2AD757C_4D709CB5_164351.png"
    ]
  },
  {
    "id": "sie-1393-2826",
    "name": "Deng Hongzhang",
    "zh": "",
    "title": "",
    "school": "School of Life Science and Technology",
    "schoolFr": "Cybersécurité",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1393/2826.htm",
    "initials": "DH",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Life Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Life_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/6/32/77/CC34D33BD8C6493BBEFDD3A9831_C1D02666_97B83.png"
    ]
  },
  {
    "id": "sie-1393-2825",
    "name": "Hu Bo",
    "zh": "",
    "title": "",
    "school": "School of Life Science and Technology",
    "schoolFr": "Cybersécurité",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1393/2825.htm",
    "initials": "HB",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Life Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Life_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/8/0C/9A/A57E82FD52A315BEB9C0A723211_09454B47_12E00D.png"
    ]
  },
  {
    "id": "sie-1393-2824",
    "name": "Liu Peng",
    "zh": "",
    "title": "",
    "school": "School of Life Science and Technology",
    "schoolFr": "Cybersécurité",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1393/2824.htm",
    "initials": "LP",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Life Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Life_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/04/BE/01481BA63AB35EFDBB6BD2580F0_3D1BB11B_A5370.png"
    ]
  },
  {
    "id": "sie-1393-2823",
    "name": "Ning Pengbo",
    "zh": "",
    "title": "",
    "school": "School of Life Science and Technology",
    "schoolFr": "Cybersécurité",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1393/2823.htm",
    "initials": "NP",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Life Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Life_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/7/B6/88/6300F0A335E4284B8E60670E657_4F39DBCA_B1AE3.png"
    ]
  },
  {
    "id": "sie-1393-2822",
    "name": "Wang Fu",
    "zh": "",
    "title": "",
    "school": "School of Life Science and Technology",
    "schoolFr": "Cybersécurité",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1393/2822.htm",
    "initials": "WF",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Life Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Life_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/6F/13/3B46716607AAA3165D28A429E88_2160D83E_B1D5F.png"
    ]
  },
  {
    "id": "sie-1393-2821",
    "name": "Wang Zhongliang",
    "zh": "",
    "title": "",
    "school": "School of Life Science and Technology",
    "schoolFr": "Cybersécurité",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1393/2821.htm",
    "initials": "WZ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Life Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Life_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/4/98/25/8FB7B1AECC462CF8F94A1513A8A_3CC6F826_D535D.png"
    ]
  },
  {
    "id": "sie-1393-2820",
    "name": "Zhan Yonghua",
    "zh": "",
    "title": "",
    "school": "School of Life Science and Technology",
    "schoolFr": "Cybersécurité",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1393/2820.htm",
    "initials": "ZY",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Life Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Life_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/1/FB/5B/3B45409EC5111A52F35D9DB0492_44A9EC4E_10218A.png"
    ]
  },
  {
    "id": "sie-1393-2819",
    "name": "Zhang Yi",
    "zh": "",
    "title": "",
    "school": "School of Life Science and Technology",
    "schoolFr": "Cybersécurité",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1393/2819.htm",
    "initials": "ZY",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Life Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Life_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/3/1E/E5/FB745765D1B34C907DE7671EF06_0A1ED4CD_EA135.png"
    ]
  },
  {
    "id": "sie-1393-2818",
    "name": "Zhu Shouping",
    "zh": "",
    "title": "",
    "school": "School of Life Science and Technology",
    "schoolFr": "Cybersécurité",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1393/2818.htm",
    "initials": "ZS",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Life Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Life_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/5F/58/55971B58416C76AA09CFB33B708_70E16B7B_10C360.png"
    ]
  },
  {
    "id": "sie-1396-3060",
    "name": "Guo Jingjing",
    "zh": "",
    "title": "",
    "school": "School of Cyber Engineering",
    "schoolFr": "Institut de technologie de Hangzhou",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1396/3060.htm",
    "initials": "GJ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Cyber Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Cyber_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/99/04/4F9E517E58F37940F0C47F126D8_7832ADF3_CD355.jpg"
    ]
  },
  {
    "id": "sie-1396-3058",
    "name": "Jiang Tao",
    "zh": "",
    "title": "",
    "school": "School of Cyber Engineering",
    "schoolFr": "Institut de technologie de Hangzhou",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1396/3058.htm",
    "initials": "JT",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Cyber Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Cyber_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/AC/A2/BBB2E9AFF44C7FB8F66C3FE21DD_449B89DD_5E757.jpg"
    ]
  },
  {
    "id": "sie-1396-3056",
    "name": "Li Zhao",
    "zh": "",
    "title": "",
    "school": "School of Cyber Engineering",
    "schoolFr": "Institut de technologie de Hangzhou",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1396/3056.htm",
    "initials": "LZ",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Cyber Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Cyber_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/C0/C7/E941D3670739BF22FFB091ACFA7_90B1F2F3_5D64E.jpg"
    ]
  },
  {
    "id": "sie-1396-3054",
    "name": "Jiang Zhongyuan",
    "zh": "",
    "title": "",
    "school": "School of Cyber Engineering",
    "schoolFr": "Institut de technologie de Hangzhou",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1396/3054.htm",
    "initials": "JZ",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Cyber Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Cyber_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/45/2A/42A7AD9C4C414304A84A92EFC13_94917A70_61352.jpg"
    ]
  },
  {
    "id": "sie-1396-2848",
    "name": "Cao Jin",
    "zh": "",
    "title": "",
    "school": "School of Cyber Engineering",
    "schoolFr": "Institut de technologie de Hangzhou",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1396/2848.htm",
    "initials": "CJ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Cyber Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Cyber_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/4/B2/76/B9ACC789DB5679658831FBEB495_E3D1611A_DECEE.png"
    ]
  },
  {
    "id": "sie-1396-2847",
    "name": "Cao Xuefei",
    "zh": "",
    "title": "",
    "school": "School of Cyber Engineering",
    "schoolFr": "Institut de technologie de Hangzhou",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1396/2847.htm",
    "initials": "CX",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Cyber Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Cyber_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/1/AB/23/1E724C1C3AB3D7FE17309D0F6E1_3CF3526E_7876F.png"
    ]
  },
  {
    "id": "sie-1396-2846",
    "name": "Fu Yulong",
    "zh": "",
    "title": "",
    "school": "School of Cyber Engineering",
    "schoolFr": "Institut de technologie de Hangzhou",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1396/2846.htm",
    "initials": "FY",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Cyber Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Cyber_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/8/ED/31/36269061E88F7968B42CB8E66A4_29D9C2FD_A265D.png"
    ]
  },
  {
    "id": "sie-1396-2845",
    "name": "Li Hui",
    "zh": "",
    "title": "",
    "school": "School of Cyber Engineering",
    "schoolFr": "Institut de technologie de Hangzhou",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1396/2845.htm",
    "initials": "LH",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Cyber Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Cyber_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/2/D1/DA/65085E3CB63D44899ECBCAB9E44_74F18BF0_B1B2D.png"
    ]
  },
  {
    "id": "sie-1396-2844",
    "name": "Miao Yinbin",
    "zh": "",
    "title": "",
    "school": "School of Cyber Engineering",
    "schoolFr": "Institut de technologie de Hangzhou",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1396/2844.htm",
    "initials": "MY",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Cyber Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Cyber_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/8/CB/FB/0396E3E211171BBA698FA20987E_9DD6D008_C1A02.png"
    ]
  },
  {
    "id": "sie-1396-2843",
    "name": "Wang Hao",
    "zh": "",
    "title": "",
    "school": "School of Cyber Engineering",
    "schoolFr": "Institut de technologie de Hangzhou",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1396/2843.htm",
    "initials": "WH",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Cyber Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Cyber_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/8/CA/54/A5E695B70B4ACB11A396FE54E8F_3EC68700_9E614.png"
    ]
  },
  {
    "id": "sie-1396-2842",
    "name": "Yan Zheng",
    "zh": "",
    "title": "",
    "school": "School of Cyber Engineering",
    "schoolFr": "Institut de technologie de Hangzhou",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1396/2842.htm",
    "initials": "YZ",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Cyber Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Cyber_Engineering.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/4/BA/F5/2912492535CDA249F4A7C3C4C00_7F36FC0C_161C3F.png"
    ]
  },
  {
    "id": "sie-1392-3072",
    "name": "Song Jianjun",
    "zh": "",
    "title": "",
    "school": "Faculty of Integrated Circuit",
    "schoolFr": "Sciences et technologies du vivant",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1392/3072.htm",
    "initials": "SJ",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Faculty of Integrated Circuit"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Faculty_of_Integrated_Circuit.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/F/2E/59/62D25C707484DAC4CEC765AE840_FB6D7E2C_4DEF7.jpg"
    ]
  },
  {
    "id": "sie-1392-2817",
    "name": "Fei Chunlong",
    "zh": "",
    "title": "",
    "school": "Faculty of Integrated Circuit",
    "schoolFr": "Sciences et technologies du vivant",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1392/2817.htm",
    "initials": "FC",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Faculty of Integrated Circuit"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Faculty_of_Integrated_Circuit.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/1D/3D/3979D597CC659495EF6B228E073_E6B8DDFD_ACC18.png"
    ]
  },
  {
    "id": "sie-1392-2816",
    "name": "He Yunlong",
    "zh": "",
    "title": "",
    "school": "Faculty of Integrated Circuit",
    "schoolFr": "Sciences et technologies du vivant",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1392/2816.htm",
    "initials": "HY",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Faculty of Integrated Circuit"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Faculty_of_Integrated_Circuit.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/6B/DF/1073D1AD9DA2FC353D7A4EFD18C_7385BA60_99B0D.png"
    ]
  },
  {
    "id": "sie-1392-2815",
    "name": "Li Cong",
    "zh": "",
    "title": "",
    "school": "Faculty of Integrated Circuit",
    "schoolFr": "Sciences et technologies du vivant",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1392/2815.htm",
    "initials": "LC",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Faculty of Integrated Circuit"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Faculty_of_Integrated_Circuit.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/7/83/28/AE0B215EF9FC37AEEDADB39AA8A_3165965D_900BB.png"
    ]
  },
  {
    "id": "sie-1392-2814",
    "name": "Li Yuan",
    "zh": "",
    "title": "",
    "school": "Faculty of Integrated Circuit",
    "schoolFr": "Sciences et technologies du vivant",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1392/2814.htm",
    "initials": "LY",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Faculty of Integrated Circuit"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Faculty_of_Integrated_Circuit.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/8C/2F/12536F68034D0AB206262510018_8B906FC8_FC1AD.png"
    ]
  },
  {
    "id": "sie-1392-2813",
    "name": "Liu Chen",
    "zh": "",
    "title": "",
    "school": "Faculty of Integrated Circuit",
    "schoolFr": "Sciences et technologies du vivant",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1392/2813.htm",
    "initials": "LC",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Faculty of Integrated Circuit"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Faculty_of_Integrated_Circuit.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/1E/4E/03C8E7ED46EB558194075A5D7F0_1DAE395A_BD2BD.png"
    ]
  },
  {
    "id": "sie-1392-2812",
    "name": "Liu Hongxia",
    "zh": "",
    "title": "",
    "school": "Faculty of Integrated Circuit",
    "schoolFr": "Sciences et technologies du vivant",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1392/2812.htm",
    "initials": "LH",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Faculty of Integrated Circuit"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Faculty_of_Integrated_Circuit.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/1/E0/C2/67C363AFBC2E6B4E4034ED4E137_5A0170B2_AB598.png"
    ]
  },
  {
    "id": "sie-1392-2811",
    "name": "Luo Zhengdong",
    "zh": "",
    "title": "",
    "school": "Faculty of Integrated Circuit",
    "schoolFr": "Sciences et technologies du vivant",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1392/2811.htm",
    "initials": "LZ",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Faculty of Integrated Circuit"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Faculty_of_Integrated_Circuit.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/B4/75/4FA1454E99B60FF8FFCF0C9F218_B6999D8A_88A0D.png"
    ]
  },
  {
    "id": "sie-1392-2810",
    "name": "Lv Hongliang",
    "zh": "",
    "title": "",
    "school": "Faculty of Integrated Circuit",
    "schoolFr": "Sciences et technologies du vivant",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1392/2810.htm",
    "initials": "LH",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Faculty of Integrated Circuit"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Faculty_of_Integrated_Circuit.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/7/24/28/9AA05E390637933B49E1D70A412_D2D13D11_A14C4.png"
    ]
  },
  {
    "id": "sie-1392-2809",
    "name": "Ning Jing",
    "zh": "",
    "title": "",
    "school": "Faculty of Integrated Circuit",
    "schoolFr": "Sciences et technologies du vivant",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1392/2809.htm",
    "initials": "NJ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Faculty of Integrated Circuit"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Faculty_of_Integrated_Circuit.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/2/C1/74/3DB2D3FBFBFB9C444B5B4F39A09_32D13BF7_BE46F.png"
    ]
  },
  {
    "id": "sie-1392-2808",
    "name": "Quan Yi",
    "zh": "",
    "title": "",
    "school": "Faculty of Integrated Circuit",
    "schoolFr": "Sciences et technologies du vivant",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1392/2808.htm",
    "initials": "QY",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Faculty of Integrated Circuit"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Faculty_of_Integrated_Circuit.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/3/24/B8/112CD70469825ADE7EE94707BCB_F132B43B_90101.png"
    ]
  },
  {
    "id": "sie-1392-2807",
    "name": "Wei Wei",
    "zh": "",
    "title": "",
    "school": "Faculty of Integrated Circuit",
    "schoolFr": "Sciences et technologies du vivant",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1392/2807.htm",
    "initials": "WW",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Faculty of Integrated Circuit"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Faculty_of_Integrated_Circuit.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/1/37/93/D5F6856FA063DA4A5F5BDAB79CA_8A0F2DAC_990FE.png"
    ]
  },
  {
    "id": "sie-1392-2806",
    "name": "Xie Min",
    "zh": "",
    "title": "",
    "school": "Faculty of Integrated Circuit",
    "schoolFr": "Sciences et technologies du vivant",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1392/2806.htm",
    "initials": "XM",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Faculty of Integrated Circuit"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Faculty_of_Integrated_Circuit.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/57/4D/8502B44782F931D4AC53DC2D5EB_5EDE4148_C0077.png"
    ]
  },
  {
    "id": "sie-1392-2805",
    "name": "Zheng Xuefeng",
    "zh": "",
    "title": "",
    "school": "Faculty of Integrated Circuit",
    "schoolFr": "Sciences et technologies du vivant",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1392/2805.htm",
    "initials": "ZX",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Faculty of Integrated Circuit"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Faculty_of_Integrated_Circuit.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/4/A7/95/6C328037BFAA476C7CC9A155D7E_1BFD79D4_87924.png"
    ]
  },
  {
    "id": "sie-1392-2804",
    "name": "Zhu Jiejie",
    "zh": "",
    "title": "",
    "school": "Faculty of Integrated Circuit",
    "schoolFr": "Sciences et technologies du vivant",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1392/2804.htm",
    "initials": "ZJ",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Faculty of Integrated Circuit"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Faculty_of_Integrated_Circuit.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/43/F7/CA47AE98A8AF37D8A6979DD054E_EBC4414A_78C03.png"
    ]
  },
  {
    "id": "sie-1397-3048",
    "name": "Gu Yu",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/3048.htm",
    "initials": "GY",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/F/BE/0F/1538C2E5A7D5ABBCABD35BCDA62_51CF20AE_7F8BE.jpg"
    ]
  },
  {
    "id": "sie-1397-3046",
    "name": "Zhu Hao",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/3046.htm",
    "initials": "ZH",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/E/CA/77/F5FDDE34FB67020310A48E166E0_5614D7D6_97381.jpg"
    ]
  },
  {
    "id": "sie-1397-3044",
    "name": "Wu Kai",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/3044.htm",
    "initials": "WK",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/3E/5D/BE08EBC6B3E62D0EF537320110D_38729CC2_550A8.jpg"
    ]
  },
  {
    "id": "sie-1397-3042",
    "name": "Ren Bo",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/3042.htm",
    "initials": "RB",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/C7/DC/F6340F6F24E4AEC6C3860D8F46F_835D3F29_5BF64.jpg"
    ]
  },
  {
    "id": "sie-1397-3040",
    "name": "Li Lingling",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/3040.htm",
    "initials": "LL",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/C9/F7/0A380ECD71A101A8097710C26DE_63CAAEB9_687F9.jpg"
    ]
  },
  {
    "id": "sie-1397-3038",
    "name": "Ding Jingyi",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/3038.htm",
    "initials": "DJ",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/F/F8/31/567FF829AACB9B6DD794D657CD7_21BF9A54_8A142.jpg"
    ]
  },
  {
    "id": "sie-1397-3036",
    "name": "Cao Xinghai",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/3036.htm",
    "initials": "CX",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/3/7B/6E/E07E37CF69CFF89184E19D32718_2EE733AC_57818.jpg"
    ]
  },
  {
    "id": "sie-1397-2892",
    "name": "Bai Jing",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2892.htm",
    "initials": "BJ",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/A/3A/37/F7578BDD8F8C5F0B55774897170_D367412A_942AA.jpg"
    ]
  },
  {
    "id": "sie-1397-2891",
    "name": "Feng Jie",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2891.htm",
    "initials": "FJ",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/7E/CF/CCD8E94042CA6439239C2314460_AFDB7BE7_A6E33.jpg"
    ]
  },
  {
    "id": "sie-1397-2890",
    "name": "Gou Shuiping",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2890.htm",
    "initials": "GS",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/4/F1/5B/0A5A0C31BF21E671FD00CA3CFA3_71DA5536_F085E.jpg"
    ]
  },
  {
    "id": "sie-1397-2889",
    "name": "Gu Jing",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2889.htm",
    "initials": "GJ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/F/FF/AF/0AF7A7BB1662AFD56E10C500534_DB3037BC_AB883.jpg"
    ]
  },
  {
    "id": "sie-1397-2888",
    "name": "Jiao Changzhe",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2888.htm",
    "initials": "JC",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/8/9D/70/EECF4661AB3D4F0FBD92CB098E0_DB9E5182_C8D3C.jpg"
    ]
  },
  {
    "id": "sie-1397-2887",
    "name": "Jiao Licheng",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2887.htm",
    "initials": "JL",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/E5/E9/BFBE5DECDD020FFD94603BD5131_86BF0794_8465D.jpg"
    ]
  },
  {
    "id": "sie-1397-2886",
    "name": "Li Yangyang",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2886.htm",
    "initials": "LY",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/66/FB/DCA450E2B61EE7842522D32B77E_0A61FF92_E8830.jpg"
    ]
  },
  {
    "id": "sie-1397-2885",
    "name": "Liang Xuefeng",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2885.htm",
    "initials": "LX",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/F/58/2E/E3E14FB6D5830B62B27999D51EB_64C68447_C09A2.jpg"
    ]
  },
  {
    "id": "sie-1397-2884",
    "name": "Liu Bo",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2884.htm",
    "initials": "LB",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/B/50/FD/18EA562DDF2A9AE2CCF53AAE7EF_1099D531_6EF6C.jpg"
    ]
  },
  {
    "id": "sie-1397-2883",
    "name": "Liu Fang",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2883.htm",
    "initials": "LF",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/E/7A/0B/6FA9FBC2F0A9E3C8D4AE5F34B11_95858072_6F2A5.jpg"
    ]
  },
  {
    "id": "sie-1397-2882",
    "name": "Liu Hongying",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2882.htm",
    "initials": "LH",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/A/EC/4D/CE3DB90CD8C6D833882B7284536_0C65E401_DBAA5.jpg"
    ]
  },
  {
    "id": "sie-1397-2881",
    "name": "Mu Caihong",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2881.htm",
    "initials": "MC",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/4/77/46/BE54765F2E9286EF155A163D059_ADAA4929_8E996.jpg"
    ]
  },
  {
    "id": "sie-1397-2880",
    "name": "Shang Ronghua",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2880.htm",
    "initials": "SR",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/1/58/2D/B09D4B674A2FF6412A74BBF7CEC_ACA70022_2B6824.jpg"
    ]
  },
  {
    "id": "sie-1394-2834",
    "name": "Chang Jing",
    "zh": "",
    "title": "",
    "school": "School of Aerospace Science and Technology",
    "schoolFr": "Circuits intégrés",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1394/2834.htm",
    "initials": "CJ",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Aerospace Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Aerospace_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/F4/C9/63BFEA266B7C4D85A94D139C03C_7EFCCEEA_B0E12.png"
    ]
  },
  {
    "id": "sie-1394-2833",
    "name": "Feng Dongzhu",
    "zh": "",
    "title": "",
    "school": "School of Aerospace Science and Technology",
    "schoolFr": "Circuits intégrés",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1394/2833.htm",
    "initials": "FD",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Aerospace Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Aerospace_Science_and_Technology.htm",
    "profileImages": []
  },
  {
    "id": "sie-1394-2832",
    "name": "Lv Xiaozhou",
    "zh": "",
    "title": "",
    "school": "School of Aerospace Science and Technology",
    "schoolFr": "Circuits intégrés",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1394/2832.htm",
    "initials": "LX",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Aerospace Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Aerospace_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/A/2C/96/54A0F8DEAEBE0F4C8B843DC18FB_2BCA51D8_81087.png"
    ]
  },
  {
    "id": "sie-1394-2831",
    "name": "Shi Lei",
    "zh": "",
    "title": "",
    "school": "School of Aerospace Science and Technology",
    "schoolFr": "Circuits intégrés",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1394/2831.htm",
    "initials": "SL",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Aerospace Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Aerospace_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/8/58/5E/835D28B236967075569D0BF7AB0_48DD904A_C2F92.png"
    ]
  },
  {
    "id": "sie-1394-2830",
    "name": "Yan Yunyi",
    "zh": "",
    "title": "",
    "school": "School of Aerospace Science and Technology",
    "schoolFr": "Circuits intégrés",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1394/2830.htm",
    "initials": "YY",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Aerospace Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Aerospace_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/EF/E6/2B5C43143CA23844EC548951B57_D6F07268_B040C.png"
    ]
  },
  {
    "id": "sie-1394-2829",
    "name": "Zhou Suiping",
    "zh": "",
    "title": "",
    "school": "School of Aerospace Science and Technology",
    "schoolFr": "Circuits intégrés",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1394/2829.htm",
    "initials": "ZS",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Aerospace Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Aerospace_Science_and_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/A/D9/2B/C3A0C14E268F19EC8614C4B283F_D17B477F_829FC.png"
    ]
  },
  {
    "id": "sie-1657-6745",
    "name": "Yu Chuang",
    "zh": "",
    "title": "",
    "school": "School of Information Mechanics and Sensing Engineering",
    "schoolFr": "Institut de technologie de Guangzhou",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1657/6745.htm",
    "initials": "YC",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Information Mechanics and Sensing Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Schoo_of_Information_Mechanics_and_Sensing_Enginee.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/1/FE/A9/5CAFFB07D1714F5F1F5F1C05D70_24AE701B_9603D4.jpg"
    ]
  },
  {
    "id": "sie-1657-6735",
    "name": "Xiao Guoyao",
    "zh": "",
    "title": "",
    "school": "School of Information Mechanics and Sensing Engineering",
    "schoolFr": "Institut de technologie de Guangzhou",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1657/6735.htm",
    "initials": "XG",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Information Mechanics and Sensing Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Schoo_of_Information_Mechanics_and_Sensing_Enginee.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/79/ED/03D087B8B6779201C5FBFB47850_6282BD9B_8DBFF0.jpg"
    ]
  },
  {
    "id": "sie-1395-6705",
    "name": "Chen Hua",
    "zh": "",
    "title": "",
    "school": "School of Advanced Materials and Nanotechnology",
    "schoolFr": "Intelligence artificielle",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1395/6705.htm",
    "initials": "CH",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Advanced Materials and Nanotechnology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Advanced_Materials_and_Nanotechnology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/CD/0D/2F16FE49626C2C2D7F85AA1EE19_EABCDB1D_4CDBBF.jpg"
    ]
  },
  {
    "id": "sie-1395-6695",
    "name": "Gu Long",
    "zh": "",
    "title": "",
    "school": "School of Advanced Materials and Nanotechnology",
    "schoolFr": "Intelligence artificielle",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1395/6695.htm",
    "initials": "GL",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Advanced Materials and Nanotechnology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Advanced_Materials_and_Nanotechnology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/E/E1/3A/D663D458F8829BE9C31F5B67C48_D47BFD8F_4131D9.jpg"
    ]
  },
  {
    "id": "sie-1395-3073",
    "name": "Wu Weiwei",
    "zh": "",
    "title": "",
    "school": "School of Advanced Materials and Nanotechnology",
    "schoolFr": "Intelligence artificielle",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1395/3073.htm",
    "initials": "WW",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Advanced Materials and Nanotechnology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Advanced_Materials_and_Nanotechnology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/1/6B/33/A5129D4C3FCF08E8A2215D7E4A6_8AEB6A93_4B29D.jpg"
    ]
  },
  {
    "id": "sie-1395-2841",
    "name": "Ajit Khosla",
    "zh": "",
    "title": "",
    "school": "School of Advanced Materials and Nanotechnology",
    "schoolFr": "Intelligence artificielle",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1395/2841.htm",
    "initials": "AK",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Advanced Materials and Nanotechnology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Advanced_Materials_and_Nanotechnology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/28/CA/66A71978114F0046D57F4952BA2_76DE766A_D2683.png"
    ]
  },
  {
    "id": "sie-1395-2840",
    "name": "Bai Xiaoxia",
    "zh": "",
    "title": "",
    "school": "School of Advanced Materials and Nanotechnology",
    "schoolFr": "Intelligence artificielle",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1395/2840.htm",
    "initials": "BX",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Advanced Materials and Nanotechnology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Advanced_Materials_and_Nanotechnology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/A/EE/1C/5755CE3A2975457450BFC3DE168_A4A304B9_1437C1.png"
    ]
  },
  {
    "id": "sie-1395-2839",
    "name": "Lei Yimin",
    "zh": "",
    "title": "",
    "school": "School of Advanced Materials and Nanotechnology",
    "schoolFr": "Intelligence artificielle",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1395/2839.htm",
    "initials": "LY",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Advanced Materials and Nanotechnology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Advanced_Materials_and_Nanotechnology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/F5/38/F460E127FBB41A2014180BCD577_EF512A8A_C3B34.png"
    ]
  },
  {
    "id": "sie-1395-2838",
    "name": "Xie Yong",
    "zh": "",
    "title": "",
    "school": "School of Advanced Materials and Nanotechnology",
    "schoolFr": "Intelligence artificielle",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1395/2838.htm",
    "initials": "XY",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Advanced Materials and Nanotechnology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Advanced_Materials_and_Nanotechnology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/4/23/8D/BEA601A81F2AD74954F170C4116_3E1C8EA2_E158E.png"
    ]
  },
  {
    "id": "sie-1395-2837",
    "name": "Yang Rusen",
    "zh": "",
    "title": "",
    "school": "School of Advanced Materials and Nanotechnology",
    "schoolFr": "Intelligence artificielle",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1395/2837.htm",
    "initials": "YR",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Advanced Materials and Nanotechnology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Advanced_Materials_and_Nanotechnology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/62/A2/E26D8ACB8005B8A5AD5CC2FD91D_12339A82_E0E31.png"
    ]
  },
  {
    "id": "sie-1395-2836",
    "name": "Zhang Dongyan",
    "zh": "",
    "title": "",
    "school": "School of Advanced Materials and Nanotechnology",
    "schoolFr": "Intelligence artificielle",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1395/2836.htm",
    "initials": "ZD",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Advanced Materials and Nanotechnology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Advanced_Materials_and_Nanotechnology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/A/14/70/DEA50C9B561AD80AC3124301B6D_FF357976_E4138.png"
    ]
  },
  {
    "id": "sie-1395-2835",
    "name": "Zhao Zhenhuan",
    "zh": "",
    "title": "",
    "school": "School of Advanced Materials and Nanotechnology",
    "schoolFr": "Intelligence artificielle",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1395/2835.htm",
    "initials": "ZZ",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Advanced Materials and Nanotechnology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Advanced_Materials_and_Nanotechnology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/2/2C/11/64B87F6707CD07576C3F0853BE6_8CE2B4DA_D17E2.png"
    ]
  },
  {
    "id": "sie-1626-3156",
    "name": "Zhao Hong",
    "zh": "",
    "title": "",
    "school": "Guangzhou Institute of Technology",
    "schoolFr": "Matériaux avancés et nanotechnologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1626/3156.htm",
    "initials": "ZH",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Guangzhou Institute of Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Guangzhou_Institute_of_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/18/A2/2D53B617BB9956438A657F9475A_A834239C_1BADC0.jpg"
    ]
  },
  {
    "id": "sie-1626-3155",
    "name": "Wang Xiaotian",
    "zh": "",
    "title": "",
    "school": "Guangzhou Institute of Technology",
    "schoolFr": "Matériaux avancés et nanotechnologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1626/3155.htm",
    "initials": "WX",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Guangzhou Institute of Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Guangzhou_Institute_of_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/B/21/4F/256754C21950629673AB1CA9C99_4C569B0E_136F40.jpg"
    ]
  },
  {
    "id": "sie-1626-3154",
    "name": "Wang Congsi",
    "zh": "",
    "title": "",
    "school": "Guangzhou Institute of Technology",
    "schoolFr": "Matériaux avancés et nanotechnologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1626/3154.htm",
    "initials": "WC",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Guangzhou Institute of Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Guangzhou_Institute_of_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/E/CC/2B/EF89B73847DAAD630E808A6B1EB_36896EF2_165D16.jpg"
    ]
  },
  {
    "id": "sie-1626-3153",
    "name": "Liu Xiaotao",
    "zh": "",
    "title": "",
    "school": "Guangzhou Institute of Technology",
    "schoolFr": "Matériaux avancés et nanotechnologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1626/3153.htm",
    "initials": "LX",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Guangzhou Institute of Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Guangzhou_Institute_of_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/FC/FF/E19A44EA92DD2DDE7EB3FA4327F_26F78594_133379.jpg"
    ]
  },
  {
    "id": "sie-1626-3152",
    "name": "Liu Jing",
    "zh": "",
    "title": "",
    "school": "Guangzhou Institute of Technology",
    "schoolFr": "Matériaux avancés et nanotechnologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1626/3152.htm",
    "initials": "LJ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Guangzhou Institute of Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Guangzhou_Institute_of_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/96/6A/2F69A2BDD1573E028A90CFE1FC2_C8087CB8_15D22F.jpg"
    ]
  },
  {
    "id": "sie-1626-3151",
    "name": "Huang Ting",
    "zh": "",
    "title": "",
    "school": "Guangzhou Institute of Technology",
    "schoolFr": "Matériaux avancés et nanotechnologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1626/3151.htm",
    "initials": "HT",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "Guangzhou Institute of Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Guangzhou_Institute_of_Technology.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/3/0F/E3/D8E951F6906549C25A8D156F610_E4464F5A_135430.jpg"
    ]
  },
  {
    "id": "sie-1385-2700",
    "name": "Yang Liying",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2700.htm",
    "initials": "YL",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/2/96/74/3738C7EB2E667DC8A84A85707C8_A1FBE281_73588.jpg"
    ]
  },
  {
    "id": "sie-1385-2699",
    "name": "Yu Liang",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2699.htm",
    "initials": "YL",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/2/7F/B7/9513512FA62130433930CFA9367_0E26C220_C87FE.jpg"
    ]
  },
  {
    "id": "sie-1385-2698",
    "name": "Yuan Xiguo",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2698.htm",
    "initials": "YX",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/A/D2/33/54B2EDB5D7A3DEC4E756EB6F261_5F2ECDBF_93375.jpg"
    ]
  },
  {
    "id": "sie-1385-2697",
    "name": "Zhang Junying",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2697.htm",
    "initials": "ZJ",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/A2/07/F71F1AB8026DEC8CDF123F82248_7AA01FC1_182369.jpg"
    ]
  },
  {
    "id": "sie-1385-2696",
    "name": "Zhang Liang",
    "zh": "",
    "title": "",
    "school": "School of Computer Science and Technology",
    "schoolFr": "Ingénierie électronique",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1385/2696.htm",
    "initials": "ZL",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Computer Science and Technology"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/A/AA/4D/54141AB62414347EB2474D807C3_98DBF93D_B91DA.jpg"
    ]
  },
  {
    "id": "sie-1384-2685",
    "name": "Ren Aifeng",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2685.htm",
    "initials": "RA",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/14/EC/4004D60294ED86EC8200DEC2AB5_4094C18E_CAA3F.png"
    ]
  },
  {
    "id": "sie-1384-2684",
    "name": "Ren Jian",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2684.htm",
    "initials": "RJ",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/A3/60/BCD360AC4472F279DEF535DC614_2433F687_9A2E9.png"
    ]
  },
  {
    "id": "sie-1384-2683",
    "name": "Shi Lingfeng",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2683.htm",
    "initials": "SL",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/8E/67/E2ADC15814F9DE33BF4DE6B94C8_D2BEA44B_C1EC2.png"
    ]
  },
  {
    "id": "sie-1384-2682",
    "name": "Tan Kangbo",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2682.htm",
    "initials": "TK",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/B/47/E2/3A9F60C7D5C6A2294837D54053C_ACB4AE6B_A21D6.png"
    ]
  },
  {
    "id": "sie-1384-2681",
    "name": "Wang Bin",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2681.htm",
    "initials": "WB",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/4A/EE/907A7C5CED73A98F2D0501ECBB2_0EAD13BF_B228D.png"
    ]
  },
  {
    "id": "sie-1384-2680",
    "name": "Wang Xinhuai",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2680.htm",
    "initials": "WX",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/38/49/3381BD6033625DA55B6E053AC7B_1C3C090E_CC60A.png"
    ]
  },
  {
    "id": "sie-1384-2679",
    "name": "Wei Feng",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2679.htm",
    "initials": "WF",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/D6/41/E288E21AE795E712AB8BD58927B_297C7031_B6649.png"
    ]
  },
  {
    "id": "sie-1384-2678",
    "name": "Wu Bian",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2678.htm",
    "initials": "WB",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/F/58/03/F288E684D38684CFCA3D906E83D_C28A30EB_CCC0E.png"
    ]
  },
  {
    "id": "sie-1384-2677",
    "name": "Xu Le",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2677.htm",
    "initials": "XL",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/D/1D/F4/CA400EDC24838C89A72FFE5F623_B20AB594_97ACA.png"
    ]
  },
  {
    "id": "sie-1384-2676",
    "name": "Yang Gang",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2676.htm",
    "initials": "YG",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/7/53/DF/E8521D358762854068E730F3EB8_B5D66113_143B5A.png"
    ]
  },
  {
    "id": "sie-1384-2675",
    "name": "Yang Xiaodong",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2675.htm",
    "initials": "YX",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/4/66/2D/A3073E0DB5F6127286EBE33B21D_3106DC8F_E7D7E.png"
    ]
  },
  {
    "id": "sie-1384-2674",
    "name": "Yin Yingzeng",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2674.htm",
    "initials": "YY",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/2/24/12/E3C4EE86368E840CE5F44C4B76E_BDA8938C_B3E64.png"
    ]
  },
  {
    "id": "sie-1384-2673",
    "name": "Zang Bo",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2673.htm",
    "initials": "ZB",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/59/5B/2F0ACD435F4CA2013F20BA1AB1C_1798272A_BF2F9.png"
    ]
  },
  {
    "id": "sie-1384-2672",
    "name": "Zhang Mingyang",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2672.htm",
    "initials": "ZM",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/2C/BA/3A711A7C87BA0E5F618E36C3BBE_E1FABE30_BBA88.png"
    ]
  },
  {
    "id": "sie-1384-2671",
    "name": "Zhang Pengfei",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2671.htm",
    "initials": "ZP",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/31/62/BAD208E96003A95BE3B2008633B_37333968_10E721.png"
    ]
  },
  {
    "id": "sie-1384-2670",
    "name": "Zheng Chunhong",
    "zh": "",
    "title": "",
    "school": "School of Electronic Engineering",
    "schoolFr": "Informatique et technologies",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1384/2670.htm",
    "initials": "ZC",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Electronic Engineering"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering/1.htm",
    "profileImages": []
  },
  {
    "id": "sie-1397-2879",
    "name": "Wang Jianing",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2879.htm",
    "initials": "WJ",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/51/B5/79EFDAB73DA539BE28E8869E29A_5EC2C852_13DB30.jpg"
    ]
  },
  {
    "id": "sie-1397-2878",
    "name": "Wang Rongfang",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2878.htm",
    "initials": "WR",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/4/99/1E/4C15CBCA5FF41FC5D00291F6C89_1540B13C_A8C08.jpg"
    ]
  },
  {
    "id": "sie-1397-2877",
    "name": "Wang Shuang",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2877.htm",
    "initials": "WS",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/1/5D/0C/BD0FEC759D8D82F464D88EF684E_DC19595A_D9A7B.jpg"
    ]
  },
  {
    "id": "sie-1397-2876",
    "name": "Wu Jianshe",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2876.htm",
    "initials": "WJ",
    "color": "#d9e5e1",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/5/DA/34/35BF9E591B5919A0E69BEB7AFB2_A02FE7C6_9BF2C.jpg"
    ]
  },
  {
    "id": "sie-1397-2875",
    "name": "Yang Shuyuan",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2875.htm",
    "initials": "YS",
    "color": "#e8ded2",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/9/3E/83/A1B26C065D3FD53B5AE6E8EE613_1C479FC2_909FC.jpg"
    ]
  },
  {
    "id": "sie-1397-2874",
    "name": "Zhang Xiaohua",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2874.htm",
    "initials": "ZX",
    "color": "#e5dfed",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/C/95/80/8F5C81FFA9C561C3BAAFF54CC26_9E9E1BC7_8008D.jpg"
    ]
  },
  {
    "id": "sie-1397-2873",
    "name": "Zhu Huming",
    "zh": "",
    "title": "",
    "school": "School of Artificial Intelligence",
    "schoolFr": "Aérospatiale",
    "field": "",
    "research": [],
    "researchFr": [],
    "levels": [],
    "languages": [],
    "email": "",
    "international": "directory",
    "source": "https://sie.xidian.edu.cn/info/1397/2873.htm",
    "initials": "ZH",
    "color": "#dce4ec",
    "note": "Official SIE directory entry. Consult the original profile document; current availability and supervision language require confirmation.",
    "schools": [
      "School of Artificial Intelligence"
    ],
    "directorySource": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence/1.htm",
    "profileImages": [
      "https://sie.xidian.edu.cn/__local/0/82/91/DA61C3C852677BD27EDB71CC760_3B63A7AB_80104.jpg"
    ]
  }
];
export const directoryMeta={
  "version": "sie-2026-10-15-v2",
  "checkedAt": "2026-10-15",
  "officialProfiles": 252,
  "additionalProfiles": 3,
  "totalProfiles": 255,
  "listPages": 22,
  "schools": [
    {
      "name": "School of Telecommunications Engineering",
      "fr": "Télécommunications",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Telecommunications_Engineering.htm",
      "count": 10
    },
    {
      "name": "School of Electronic Engineering",
      "fr": "Informatique et technologies",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Electronic_Engineering.htm",
      "count": 36
    },
    {
      "name": "School of Computer Science and Technology",
      "fr": "Ingénierie électronique",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Computer_Science_and_Technology.htm",
      "count": 25
    },
    {
      "name": "School of Mechano-electronic Engineering",
      "fr": "Génie mécatronique",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mechano_electronic_Engineering.htm",
      "count": 18
    },
    {
      "name": "School of Physics",
      "fr": "Économie et gestion",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Physics.htm",
      "count": 13
    },
    {
      "name": "School of Optoelectronic Engineering",
      "fr": "Physique",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Optoelectronic_Engineering.htm",
      "count": 11
    },
    {
      "name": "School of Economics and Management",
      "fr": "Mathématiques et statistiques",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Economics_and_Management.htm",
      "count": 18
    },
    {
      "name": "School of Mathematics and Statistics",
      "fr": "Optoélectronique",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Mathematics_and_Statistics.htm",
      "count": 7
    },
    {
      "name": "School of Humanities and Arts",
      "fr": "Sciences humaines et arts",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Humanities_and_Arts.htm",
      "count": 19
    },
    {
      "name": "School of Foreign Languages",
      "fr": "Langues étrangères",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Foreign_Languages.htm",
      "count": 4
    },
    {
      "name": "Faculty of Integrated Circuit",
      "fr": "Sciences et technologies du vivant",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Faculty_of_Integrated_Circuit.htm",
      "count": 15
    },
    {
      "name": "School of Life Science and Technology",
      "fr": "Cybersécurité",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Life_Science_and_Technology.htm",
      "count": 14
    },
    {
      "name": "School of Aerospace Science and Technology",
      "fr": "Circuits intégrés",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Aerospace_Science_and_Technology.htm",
      "count": 6
    },
    {
      "name": "School of Advanced Materials and Nanotechnology",
      "fr": "Intelligence artificielle",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Advanced_Materials_and_Nanotechnology.htm",
      "count": 10
    },
    {
      "name": "School of Cyber Engineering",
      "fr": "Institut de technologie de Hangzhou",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Cyber_Engineering.htm",
      "count": 11
    },
    {
      "name": "School of Artificial Intelligence",
      "fr": "Aérospatiale",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/School_of_Artificial_Intelligence.htm",
      "count": 27
    },
    {
      "name": "Hangzhou Institute of Technology",
      "fr": "Mécanique de l’information et capteurs",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Hangzhou_Institute_of_Technology.htm",
      "count": 0
    },
    {
      "name": "Guangzhou Institute of Technology",
      "fr": "Matériaux avancés et nanotechnologies",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Guangzhou_Institute_of_Technology.htm",
      "count": 6
    },
    {
      "name": "School of Information Mechanics and Sensing Engineering",
      "fr": "Institut de technologie de Guangzhou",
      "url": "https://sie.xidian.edu.cn/EN/Study_in_China/Admissoin/Graduate_Program/Supervisors1/Schoo_of_Information_Mechanics_and_Sensing_Enginee.htm",
      "count": 2
    }
  ]
};
