# Xidian International Hub + Xie-Visas

Prototype responsive pour GitHub Pages, créé pour présenter une plateforme d’accompagnement des étudiants internationaux de Xidian.

## Modules du prototype

- Tableau de bord étudiant et ISO simulé.
- Annuaire initial de trois superviseurs avec sources officielles, filtres, favoris et modèle d’email.
- Gestion locale des dates de documents, niveaux d’urgence et rappels dans l’application.
- Export calendrier ICS avec rappels 30/15/7/1 jours, CSV, JSON et impression PDF.
- Guide d’arrivée et checklist interactive.
- FAQ documentaire FR/EN/ZH sans IA générative connectée.
- Navigation dans onze langues ; contenus détaillés FR/EN/ZH et RTL pour arabe, darija et ourdou.

## Démonstration et confidentialité

GitHub Pages est statique. Aucune API distante ni authentification réelle n’est utilisée par ce prototype. Les rôles sont simulés et les exemples sont fictifs. « Tester mon espace local » permet de tester les interactions ; les données restent uniquement dans le stockage local de ce navigateur. Elles ne sont pas synchronisées entre appareils. N’entrez pas de données personnelles sensibles.

Les modifications faites en mode découverte sont réinitialisées au rechargement. Les modifications faites dans l’espace local sont conservées sur cet appareil. Aucun email, SMS ou message WeChat n’est envoyé. Aucun planificateur ne s’exécute lorsque la page est fermée. Les alertes locales sont évaluées à l’ouverture ; les rappels ICS dépendent des réglages du calendrier importateur.

## Lancer en local

Node.js 22 ou supérieur.

```bash
npm ci
npm run dev
```

## Vérifier et compiler

```bash
npm test
npm run build
npm run preview
```

Le résultat statique est dans `dist/`. Les liens utilisent des fragments (`#/visas`, `#/supervisors`) et les assets des chemins relatifs : le site fonctionne dans un sous-répertoire GitHub Pages et après rechargement de chaque page.

## Publier sur GitHub Pages

Le workflow `.github/workflows/pages.yml` compile et publie à chaque push sur `main`.

1. Créer le dépôt `xidian-international-hub` sur GitHub.
2. Y publier le code.
3. Dans **Settings → Pages → Build and deployment → Source**, sélectionner **GitHub Actions**.
4. Attendre la réussite du workflow **Deploy prototype to GitHub Pages**.

L’URL finale est indiquée par l’environnement `github-pages` et l’étape `actions/deploy-pages`. Ne pas considérer une URL comme publiée avant la réussite du workflow.

## Source de la version serveur

`server-app/` conserve les modules React, les routes API, les schémas Drizzle, les migrations et les tests de la version serveur précédente. Ces fichiers ne sont pas exécutés par GitHub Pages. `docs/server-pilot.md` décrit cette architecture et les services restant à connecter. Aucun identifiant d’hébergement, secret, compte administrateur ou donnée d’utilisateur n’est inclus.

## Sources et statut institutionnel

Les fiches initiales s’appuient sur les pages publiques officielles de Li Chenxi, Li Jun et Sheng Kai. La disponibilité des enseignants et la langue de supervision doivent être confirmées directement. Le guide renvoie aux sources de la National Immigration Administration. Les règles administratives doivent être vérifiées avec l’ISO et les autorités compétentes.

Initiative étudiante indépendante ; aucune affiliation officielle à Xidian, validation ISO ou certification réglementaire n’est revendiquée. Le mini-programme WeChat, les notifications externes et le RAG ne sont pas connectés dans ce prototype.
