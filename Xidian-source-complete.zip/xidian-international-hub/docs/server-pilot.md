# Xidian International Hub · Xie-Visas

Version web pilote complète, déployable via Sites. Initiative étudiante indépendante ; ne revendique ni affiliation officielle à Xidian, ni certification réglementaire.

## Utiliser le site

- La page d’accueil s’ouvre en mode découverte avec des données fictives.
- « Ouvrir mon espace » active l’espace associé à votre connexion ChatGPT. Les documents, le profil, les favoris, les filtres et la checklist sont enregistrés côté serveur.
- Xie-Visas : ajouter/modifier/supprimer les dates, voir les niveaux d’urgence, télécharger un calendrier ICS avec rappels 30/15/7/1 jours.
- Superviseurs : recherche et filtres, favoris, liens vers les sources officielles, modèle d’email à copier ou télécharger. Trois profils initiaux, sans disponibilité actuelle garantie.
- Guide : neuf démarches interactives, liens vers les cartes Amap et les consignes NIA.
- Assistant : FAQ documentaire en FR/EN/ZH, réponses prédéfinies et liens sources. Aucun modèle IA connecté.
- ISO : démonstration fictive ; les véritables données et rappels groupés exigent un rôle administrateur. Exports CSV et impression PDF.

## Architecture livrée

React 19, TypeScript, Vinext (API compatible Next), CSS responsive, GSAP, Worker Cloudflare et D1 SQLite avec Drizzle. Ce choix permet de publier dans l’environnement disponible ; ce déploiement n’utilise pas PostgreSQL, Redis, NestJS ou Alibaba Cloud.

Pages : `/`, `/supervisors`, `/visas`, `/guide`, `/chat`, `/dashboard`, `/admin`, `/settings`.
API OpenAPI 3.1 : `/api/openapi`.

L’authentification est fournie par Sites. Les API vérifient l’identité puis la propriété des données. Les rôles ISO sont vérifiés sur le serveur via l’allowlist `ISO_ADMIN_EMAILS`. Un changement d’onglet ne donne aucun droit.

Tables : `profiles`, `documents`, `alerts`. Seules les dates et métadonnées sont collectées : aucun numéro ni scan de passeport. Toutes les écritures sont authentifiées ; les écritures inter-origines sont rejetées. Le front n’embarque aucun secret.

## Développement et vérifications

Node >=22.13.0. Installer avec le helper Sites ; `node node_modules/typescript/bin/tsc --noEmit`. Tests : `node --experimental-strip-types --test tests/domain.test.mjs`. Générer les migrations : `npm run db:generate`. Le build passe par le helper Sites officiel. Les migrations SQL et leur journal sont versionnés.

Aucun navigateur de QA n’était disponible dans l’environnement de construction : compiler, contrôler les types et exécuter les tests ne remplace pas une recette visuelle sur appareils réels.

## Langues

Navigation et libellés communs : français, anglais, chinois, arabe, espagnol, lingala, russe, turc, darija marocaine, turkmène, ourdou. Contenus détaillés FR/EN/ZH ; les autres langues affichent le contenu de référence en anglais avec une indication visible. Traductions à valider humainement et compléter avant lancement institutionnel. Direction RTL pour arabe, darija et ourdou.

## Notifications et planification

Le serveur évalue les dates à chaque ouverture de l’espace personnel et génère des notifications in-app idempotentes. Une clé unique combine document, expiration et seuil pour éviter les doublons. Les calculs suivent le jour civil de Pékin, y compris au passage de minuit.

Pour une évaluation quotidienne sans visite, configurer `CRON_SECRET` dans les secrets d’environnement Sites et un ordonnanceur externe qui fait `POST /api/cron` avec `Authorization: Bearer <secret>` tous les jours à **00:00 UTC / 08:00 Asia/Shanghai**. L’endpoint refuse de fonctionner si aucun secret n’est configuré. Aucun ordonnanceur externe n’est actuellement connecté. Le calendrier ICS constitue une alternative utilisable dès maintenant, sous réserve des réglages de notification du calendrier importateur.

Les canaux WeChat, SMS, email et FCM ne sont pas connectés. Les rappels in-app ne sont pas présentés comme des emails envoyés. Brancher un service d’envoi, le consentement, les préférences de notification, les reprises après échec et les quotas avant d’activer ces canaux.

## Accès ISO

Configurer `ISO_ADMIN_EMAILS` avec une liste d’emails autorisés séparés par des virgules, comme secret d’environnement Sites. Redéployer une version sauvegardée pour appliquer le changement. Cette variable ne se trouve pas dans le code ni dans le manifeste. Les administrateurs peuvent consulter les profils, dates et alertes et créer des rappels in-app collectifs. Les autres rôles institutionnels ne sont pas encore provisionnés.

## Conditions avant exploitation institutionnelle

- Obtenir l’accord de l’ISO et la validation des contenus ainsi qu’une politique de conservation/effacement.
- Compléter et valider les traductions et le répertoire de superviseurs ; confirmer les droits de collecte automatisée et les limites de réutilisation des pages sources.
- Faire auditer la sécurité, les accès, les sauvegardes, la localisation des données et les obligations chinoises/RGPD applicables. Ne pas afficher une conformité MLPS 2.0 ou RGPD sans validation.
- Choisir les infrastructures China/international et effectuer des tests réels d’accessibilité, de performance et de restauration.
- Configurer les fournisseurs de notifications et le planificateur.
- Pour l’IA : une vraie base documentaire validée, un index RAG, un secret fournisseur, une traçabilité des citations et une évaluation.
- Le mini-programme WeChat n’est pas publié : AppID, compte institutionnel, domaines autorisés, consentements, template messages et validation Tencent sont nécessaires. Yipai est un formateur d’articles de compte officiel, pas un service de publication de mini-programmes.

## Sources consultées le 15 octobre 2026

- Li Chenxi : https://faculty.xidian.edu.cn/LICHENXI/en/index.htm
- Li Jun : https://web.xidian.edu.cn/junli/
- Sheng Kai, annonce 2025 : https://faculty.xidian.edu.cn/shengkai/zh_CN/zsxx/421782/content/2331.htm
- NIA, permis : https://en.nia.gov.cn/n147423/n147478/n147715/c158270/content.html
- NIA, hébergement : https://en.nia.gov.cn/n147418/n147463/c197328/content.html
- Visa X1/X2 : https://www.visaforchina.cn/JKT3_EN
- Annuaire SIE fourni, inaccessible à la consultation : https://sie.xidian.edu.cn/lhk/zsjz/yjsxm/dsdw1/txgcyx.htm
