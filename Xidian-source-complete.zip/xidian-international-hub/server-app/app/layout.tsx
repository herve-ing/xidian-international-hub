import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'Xidian International Hub · Xie-Visas',description:'Votre parcours à Xidian : superviseurs, échéances administratives et guide d’arrivée.',icons:{icon:'/favicon.svg'}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="fr"><body>{children}</body></html>}
