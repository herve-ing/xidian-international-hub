import { generateAlerts,api,ApiError } from '@/lib/server';
export const dynamic='force-dynamic';
export async function POST(r:Request){return api(async()=>{const secret=process.env.CRON_SECRET;if(!secret)throw new ApiError(503,'Scheduler not configured');if(r.headers.get('authorization')!==`Bearer ${secret}`)throw new ApiError(403,'Forbidden');return {created:await generateAlerts(),channel:'in-app',timeZone:'Asia/Shanghai'};});}
