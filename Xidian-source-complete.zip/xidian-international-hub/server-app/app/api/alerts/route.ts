import { api,identity,writeGuard } from '@/lib/server';import { getDb } from '@/db';import { alerts } from '@/db/schema';import { eq } from 'drizzle-orm';
export const dynamic='force-dynamic';
export async function PATCH(r:Request){return api(async()=>{writeGuard(r);const u=await identity();await getDb().update(alerts).set({status:'read'}).where(eq(alerts.userId,u.userId));return {saved:true};});}
