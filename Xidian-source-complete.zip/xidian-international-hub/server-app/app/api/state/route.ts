import { api,identity,isAdmin,generateAlerts } from '@/lib/server';
import { getDb } from '@/db';
import { profiles,documents,alerts } from '@/db/schema';
import { eq,desc } from 'drizzle-orm';
export const dynamic='force-dynamic';
export async function GET(){return api(async()=>{const u=await identity();const db=getDb();await generateAlerts(u.userId);const p=(await db.select().from(profiles).where(eq(profiles.userId,u.userId)))[0];return {user:{name:u.displayName,email:u.email,admin:isAdmin(u.email)},profile:p||null,documents:await db.select().from(documents).where(eq(documents.userId,u.userId)),alerts:await db.select().from(alerts).where(eq(alerts.userId,u.userId)).orderBy(desc(alerts.sentAt)),channels:{inApp:true,email:false,wechat:false,sms:false},mode:'live'};});}
