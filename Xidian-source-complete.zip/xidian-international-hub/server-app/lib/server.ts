import { getChatGPTUser } from '@/app/chatgpt-auth';
import { getDb } from '@/db';
import { documents, alerts } from '@/db/schema';
import { eq } from 'drizzle-orm';
import { alertThreshold, remainingDays } from './domain';
export class ApiError extends Error { constructor(public status:number, message:string){super(message);} }
export async function identity(){ const user=await getChatGPTUser(); if(!user) throw new ApiError(401,'Sign in to save your information.'); return user; }
export function isAdmin(email:string){ return (process.env.ISO_ADMIN_EMAILS || '').split(',').map(s=>s.trim().toLowerCase()).filter(Boolean).includes(email.toLowerCase()); }
export async function jsonBody(request:Request){ if(Number(request.headers.get('content-length') || 0)>32768) throw new ApiError(413,'Request too large'); const raw=await request.text();if(raw.length>32768)throw new ApiError(413,'Request too large');try{return JSON.parse(raw);}catch{throw new ApiError(400,'Invalid JSON');} }
export function writeGuard(request:Request){const origin=request.headers.get('origin');if(origin && new URL(origin).host!==new URL(request.url).host)throw new ApiError(403,'Origin mismatch');}
export async function api(fn:()=>Promise<unknown>){ try{return Response.json(await fn(),{headers:{'Cache-Control':'no-store'}});}catch(e){if(e instanceof ApiError)return Response.json({error:e.message},{status:e.status});console.error('API request failed', e instanceof Error ? e.message : 'unknown');return Response.json({error:'Service temporarily unavailable. Your changes were not saved.'},{status:503});} }
export async function generateAlerts(userId?:string){const db=getDb();const docs=userId?await db.select().from(documents).where(eq(documents.userId,userId)):await db.select().from(documents);let count=0; for(const d of docs){const days=remainingDays(d.expiry);const threshold=alertThreshold(days);if(threshold===null)continue;const id=[d.id,d.expiry,threshold].join(':');const r=await db.insert(alerts).values({id,userId:d.userId,documentId:d.id,documentType:d.type,message:days<0?`${d.label}: expired ${Math.abs(days)} day(s) ago.`:`${d.label}: ${days} day(s) remaining.`,threshold:String(threshold),channel:'in-app',status:'unread',sentAt:new Date().toISOString()}).onConflictDoNothing().returning({id:alerts.id});count+=r.length;}return count;}
