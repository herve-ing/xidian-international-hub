import { sqliteTable, text } from 'drizzle-orm/sqlite-core';
export const profiles = sqliteTable('profiles', {
  userId: text('user_id').primaryKey(),
  displayName: text('display_name').notNull().default(''),
  nationality: text('nationality').notNull().default(''),
  studentId: text('student_id').notNull().default(''),
  program: text('program').notNull().default('Master'),
  arrivalDate: text('arrival_date'),
  registrationDate: text('registration_date'),
  checklist: text('checklist').notNull().default('[]'),
  preferences: text('preferences').notNull().default('{}'),
  updatedAt: text('updated_at').notNull(),
});
export const documents = sqliteTable('documents', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull(),
  type: text('type').notNull(),
  label: text('label').notNull(),
  issueDate: text('issue_date'),
  expiry: text('expiry').notNull(),
  updatedAt: text('updated_at').notNull(),
});
export const alerts = sqliteTable('alerts', {
  id: text('id').primaryKey(), userId: text('user_id').notNull(),
  documentId: text('document_id').notNull(), documentType: text('document_type').notNull(),
  message: text('message').notNull(), threshold: text('threshold').notNull(),
  channel: text('channel').notNull().default('in-app'),
  status: text('status').notNull().default('unread'), sentAt: text('sent_at').notNull(),
});
export const supervisorRecords = sqliteTable('supervisor_records', {
  id:text('id').primaryKey(), data:text('data').notNull(), updatedBy:text('updated_by').notNull(), updatedAt:text('updated_at').notNull()
});
