CREATE TABLE `supervisor_records` (
	`id` text PRIMARY KEY NOT NULL,
	`data` text NOT NULL,
	`updated_by` text NOT NULL,
	`updated_at` text NOT NULL
);
