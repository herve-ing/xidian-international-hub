CREATE TABLE `alerts` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`document_id` text NOT NULL,
	`document_type` text NOT NULL,
	`message` text NOT NULL,
	`threshold` text NOT NULL,
	`channel` text DEFAULT 'in-app' NOT NULL,
	`status` text DEFAULT 'unread' NOT NULL,
	`sent_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `documents` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`type` text NOT NULL,
	`label` text NOT NULL,
	`issue_date` text,
	`expiry` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `profiles` (
	`user_id` text PRIMARY KEY NOT NULL,
	`display_name` text DEFAULT '' NOT NULL,
	`nationality` text DEFAULT '' NOT NULL,
	`student_id` text DEFAULT '' NOT NULL,
	`program` text DEFAULT 'Master' NOT NULL,
	`arrival_date` text,
	`registration_date` text,
	`checklist` text DEFAULT '[]' NOT NULL,
	`preferences` text DEFAULT '{}' NOT NULL,
	`updated_at` text NOT NULL
);
